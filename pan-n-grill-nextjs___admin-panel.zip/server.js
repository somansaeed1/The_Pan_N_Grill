require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');

// Import routes
const categoryRoutes = require('./routes/categoryRoutes');
const productRoutes = require('./routes/productRoutes');
const orderRoutes = require('./routes/orderRoutes');
const mediaRoutes = require('./routes/mediaRoutes');
const searchRoutes = require('./routes/searchRoutes');
const adminAuthRoutes = require('./routes/adminAuthRoutes');
const dashboardRoutes = require('./routes/dashboardRoutes');
const userRoutes = require('./routes/userRoutes');
const adminSearchRoutes = require('./routes/adminSearchRoutes');
const settingsRoutes = require('./routes/settingsRoutes');
const activityLogRoutes = require('./routes/activityLogRoutes');

// Import middleware
const { logAdminActivity, logAuthActivity } = require('./middleware/activityLogger');
const { errorHandler, notFound } = require('./middleware/errorHandler');
const { sanitizeInput } = require('./middleware/validation');
const { generalLimiter, authLimiter, adminMutationLimiter } = require('./middleware/rateLimiter');

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 5000;

// CORS must come first
app.use(cors());

// Body parsing middleware MUST come before any other middleware that uses req.body
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Serve static files from uploads directory
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Temporarily disable rate limiting and sanitization for debugging
// app.use('/api/', generalLimiter);
// app.use(sanitizeInput);

// Database Connection
mongoose.connect(process.env.MONGODB_URI)
.then(() => {
  console.log('✅ Successfully connected to MongoDB');
  console.log(`📊 Database: ${mongoose.connection.name}`);
})
.catch((error) => {
  console.error('❌ MongoDB connection error:', error.message);
  process.exit(1);
});

// Routes
app.get('/', (req, res) => {
  res.json({
    success: true,
    message: 'Welcome to Pan-n-Grill API',
    version: '2.0.0',
    endpoints: {
      categories: '/api/categories',
      products: '/api/products',
      orders: '/api/orders',
      media: '/api/media',
      search: '/api/search',
      adminAuth: '/api/admin/auth',
      adminDashboard: '/api/admin/dashboard'
    },
    features: {
      fileUpload: 'Products can be created with image upload',
      mediaManagement: 'Upload, list, and delete media files',
      search: 'Global search across all collections',
      imageCleanup: 'Optional image deletion when removing products'
    }
  });
});

// API Routes
// Public routes (no logging)
app.use('/api/categories', categoryRoutes);
app.use('/api/products', productRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/search', searchRoutes);
app.use('/api/settings', settingsRoutes);

// Admin routes (temporarily disable activity logging and rate limiting for debugging)
app.use('/api/admin/auth', adminAuthRoutes);
app.use('/api/admin/dashboard', dashboardRoutes);
app.use('/api/admin/search', adminSearchRoutes);
app.use('/api/admin/settings', settingsRoutes);
app.use('/api/admin/activity-logs', activityLogRoutes);

// Resource management routes (temporarily disable activity logging and rate limiting for debugging)
app.use('/api/media', mediaRoutes);
app.use('/api/users', userRoutes);

// 404 Handler
app.use(notFound);

// Centralized Error Handler
app.use(errorHandler);

// Start Server
app.listen(PORT, () => {
  console.log(`🚀 Server is running on http://localhost:${PORT}`);
  console.log(`📡 Environment: ${process.env.NODE_ENV || 'development'}`);
});

module.exports = app;
