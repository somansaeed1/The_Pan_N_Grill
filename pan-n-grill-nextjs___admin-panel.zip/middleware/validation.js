const { body, param, query, validationResult } = require('express-validator');
const { AppError } = require('./errorHandler');

/**
 * Middleware to check validation results
 */
const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const errorMessages = errors.array().map(err => err.msg).join(', ');
    return next(new AppError(errorMessages, 400));
  }
  next();
};

/**
 * Common validation rules
 */
const validations = {
  // MongoDB ObjectId validation
  objectId: (field = 'id') => [
    param(field)
      .isMongoId()
      .withMessage(`Invalid ${field} format`)
  ],

  // Email validation
  email: (field = 'email') => [
    body(field)
      .trim()
      .isEmail()
      .withMessage('Please provide a valid email address')
      .normalizeEmail()
  ],

  // Password validation
  password: (field = 'password') => [
    body(field)
      .isLength({ min: 6 })
      .withMessage('Password must be at least 6 characters long')
      .matches(/\d/)
      .withMessage('Password must contain at least one number')
  ],

  // Name validation
  name: (field = 'name', minLength = 2) => [
    body(field)
      .trim()
      .isLength({ min: minLength })
      .withMessage(`${field} must be at least ${minLength} characters`)
      .matches(/^[a-zA-Z\s]+$/)
      .withMessage(`${field} must contain only letters and spaces`)
  ],

  // Phone validation
  phone: (field = 'phone') => [
    body(field)
      .trim()
      .matches(/^[\d\s\-\+\(\)]+$/)
      .withMessage('Please provide a valid phone number')
  ],

  // Price validation
  price: (field = 'price') => [
    body(field)
      .isFloat({ min: 0 })
      .withMessage(`${field} must be a positive number`)
  ],

  // Quantity validation
  quantity: (field = 'quantity') => [
    body(field)
      .isInt({ min: 1 })
      .withMessage(`${field} must be at least 1`)
  ],

  // Status validation
  status: (field = 'status', allowedValues = []) => [
    body(field)
      .isIn(allowedValues)
      .withMessage(`Invalid ${field}. Allowed values: ${allowedValues.join(', ')}`)
  ],

  // Pagination validation
  pagination: () => [
    query('page')
      .optional()
      .isInt({ min: 1 })
      .withMessage('Page must be a positive integer'),
    query('limit')
      .optional()
      .isInt({ min: 1, max: 100 })
      .withMessage('Limit must be between 1 and 100')
  ],

  // Date validation
  date: (field) => [
    body(field)
      .optional()
      .isISO8601()
      .withMessage(`${field} must be a valid date`)
  ],

  // Boolean validation
  boolean: (field) => [
    body(field)
      .isBoolean()
      .withMessage(`${field} must be a boolean value`)
  ],

  // Required field validation
  required: (field, fieldType = 'string') => [
    body(field)
      .exists({ checkFalsy: true })
      .withMessage(`${field} is required`)
  ],

  // Array validation
  array: (field, minLength = 1) => [
    body(field)
      .isArray({ min: minLength })
      .withMessage(`${field} must be an array with at least ${minLength} item(s)`)
  ],

  // Sanitize input
  sanitize: (field) => [
    body(field)
      .trim()
      .escape()
  ]
};

/**
 * Specific validation chains for common operations
 */
const validationChains = {
  // Admin login
  adminLogin: [
    body('email').trim().isEmail().withMessage('Please provide a valid email'),
    body('password').exists().withMessage('Password is required'),
    validate
  ],

  // Admin signup
  adminSignup: [
    body('name').trim().isLength({ min: 2 }).withMessage('Name must be at least 2 characters'),
    body('email').trim().isEmail().withMessage('Please provide a valid email'),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
    body('role').optional().isIn(['super-admin', 'admin', 'manager']).withMessage('Invalid role'),
    validate
  ],

  // Create product
  createProduct: [
    body('name').trim().notEmpty().withMessage('Product name is required'),
    body('price').isFloat({ min: 0 }).withMessage('Price must be a positive number'),
    body('category').isMongoId().withMessage('Invalid category ID'),
    body('description').optional().trim(),
    validate
  ],

  // Update order status
  updateOrderStatus: [
    param('id').isMongoId().withMessage('Invalid order ID'),
    body('status').isIn(['pending', 'preparing', 'ready', 'completed', 'cancelled']).withMessage('Invalid status'),
    body('notes').optional().trim(),
    validate
  ],

  // Block user
  blockUser: [
    param('id').isMongoId().withMessage('Invalid user ID'),
    body('reason').optional().trim(),
    validate
  ],

  // Search validation
  search: [
    query('q').optional().trim().isLength({ min: 1 }).withMessage('Search query must not be empty'),
    query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
    query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100'),
    validate
  ]
};

/**
 * Sanitize request body to prevent NoSQL injection
 */
const sanitizeInput = (req, res, next) => {
  try {
    if (req.body && typeof req.body === 'object') {
      req.body = sanitizeObject(req.body);
    }
    if (req.params && typeof req.params === 'object') {
      req.params = sanitizeObject(req.params);
    }
    if (req.query && typeof req.query === 'object') {
      req.query = sanitizeObject(req.query);
    }
  } catch (error) {
    console.error('Sanitization error:', error);
  }
  next();
};

function sanitizeObject(obj) {
  if (!obj || typeof obj !== 'object') return obj;
  
  // Handle arrays
  if (Array.isArray(obj)) {
    return obj.map(item => sanitizeObject(item));
  }
  
  const sanitized = {};
  for (const key in obj) {
    if (!obj.hasOwnProperty(key)) continue;
    
    // Remove $ operators (NoSQL injection prevention)
    if (key.startsWith('$')) continue;
    
    if (obj[key] && typeof obj[key] === 'object') {
      sanitized[key] = sanitizeObject(obj[key]);
    } else {
      sanitized[key] = obj[key];
    }
  }
  return sanitized;
}

module.exports = {
  validate,
  validations,
  validationChains,
  sanitizeInput
};
