const AdminLog = require('../models/AdminLog');

/**
 * Middleware to log admin mutations (POST, PUT, PATCH, DELETE)
 * Should be applied after authentication middleware
 */
const logAdminActivity = (options = {}) => {
  const { resourceType = 'Other', getResourceId = null } = options;

  return async (req, res, next) => {
    // Only log mutations (POST, PUT, PATCH, DELETE)
    const mutationMethods = ['POST', 'PUT', 'PATCH', 'DELETE'];
    if (!mutationMethods.includes(req.method)) {
      return next();
    }

    // Check if admin is authenticated
    if (!req.user && !req.admin) {
      return next(); // Skip logging if not authenticated
    }

    const admin = req.user || req.admin;

    // Store original res.json to intercept response
    const originalJson = res.json;
    const originalSend = res.send;

    let responseBody;
    let statusCode = res.statusCode;

    // Intercept res.json
    res.json = function(body) {
      responseBody = body;
      statusCode = res.statusCode;
      
      // Log the activity after response is sent
      logActivity();
      
      // Call original json method
      return originalJson.call(this, body);
    };

    // Intercept res.send (backup)
    res.send = function(body) {
      if (!responseBody) {
        try {
          responseBody = typeof body === 'string' ? JSON.parse(body) : body;
        } catch (e) {
          responseBody = body;
        }
        statusCode = res.statusCode;
        logActivity();
      }
      return originalSend.call(this, body);
    };

    // Function to log the activity
    const logActivity = async () => {
      try {
        // Determine resource ID
        let resourceId = null;
        if (typeof getResourceId === 'function') {
          resourceId = getResourceId(req, responseBody);
        } else if (req.params.id) {
          resourceId = req.params.id;
        } else if (responseBody?.data?._id) {
          resourceId = responseBody.data._id;
        } else if (responseBody?.data?.id) {
          resourceId = responseBody.data.id;
        }

        // Determine action description
        const action = generateActionDescription(req.method, req.path, resourceType);

        // Create log entry
        await AdminLog.logAction({
          admin: admin._id,
          action,
          method: req.method,
          endpoint: req.originalUrl || req.url,
          resourceType,
          resourceId: resourceId ? String(resourceId) : undefined,
          changes: {
            body: req.body,
            params: req.params,
            query: req.query
          },
          statusCode,
          ipAddress: req.ip || req.connection.remoteAddress,
          userAgent: req.get('user-agent'),
          success: statusCode >= 200 && statusCode < 300,
          errorMessage: statusCode >= 400 ? responseBody?.message : undefined
        });
      } catch (error) {
        console.error('Failed to log admin activity:', error);
        // Don't throw error - logging failure shouldn't break the request
      }
    };

    next();
  };
};

/**
 * Generate human-readable action description
 */
function generateActionDescription(method, path, resourceType) {
  const pathLower = path.toLowerCase();
  
  // Method-based descriptions
  if (method === 'POST') {
    if (pathLower.includes('login')) return 'Admin login';
    if (pathLower.includes('logout')) return 'Admin logout';
    if (pathLower.includes('signup')) return 'Admin signup';
    if (pathLower.includes('upload')) return `Upload ${resourceType} image`;
    return `Create ${resourceType}`;
  }
  
  if (method === 'PUT') {
    return `Update ${resourceType}`;
  }
  
  if (method === 'PATCH') {
    if (pathLower.includes('status')) return `Update ${resourceType} status`;
    if (pathLower.includes('availability')) return `Update ${resourceType} availability`;
    if (pathLower.includes('block')) return `Block ${resourceType}`;
    if (pathLower.includes('unblock')) return `Unblock ${resourceType}`;
    if (pathLower.includes('restore')) return `Restore ${resourceType}`;
    if (pathLower.includes('toggle')) return `Toggle ${resourceType}`;
    return `Update ${resourceType}`;
  }
  
  if (method === 'DELETE') {
    if (pathLower.includes('permanent')) return `Permanently delete ${resourceType}`;
    if (pathLower.includes('image')) return `Delete ${resourceType} image`;
    return `Delete ${resourceType}`;
  }
  
  return `${method} ${resourceType}`;
}

/**
 * Log authentication activities (login, logout, token refresh)
 */
const logAuthActivity = async (req, res, next) => {
  const originalJson = res.json;
  
  res.json = function(body) {
    // Log after successful response
    if (res.statusCode >= 200 && res.statusCode < 300 && body.success) {
      const action = determineAuthAction(req.path);
      const adminId = req.admin?._id || req.user?._id || body.data?.admin?._id;
      
      if (adminId) {
        AdminLog.logAction({
          admin: adminId,
          action,
          method: req.method,
          endpoint: req.originalUrl || req.url,
          resourceType: 'Admin',
          statusCode: res.statusCode,
          ipAddress: req.ip || req.connection.remoteAddress,
          userAgent: req.get('user-agent'),
          success: true
        }).catch(err => console.error('Failed to log auth activity:', err));
      }
    }
    
    return originalJson.call(this, body);
  };
  
  next();
};

function determineAuthAction(path) {
  if (path.includes('login')) return 'Admin login';
  if (path.includes('logout')) return 'Admin logout';
  if (path.includes('refresh')) return 'Token refresh';
  if (path.includes('password')) return 'Password change';
  return 'Authentication activity';
}

module.exports = {
  logAdminActivity,
  logAuthActivity
};
