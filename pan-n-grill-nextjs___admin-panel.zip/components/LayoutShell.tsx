"use client";

import React from 'react';
import { usePathname } from 'next/navigation';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import CartDrawer from '@/components/Cart/CartDrawer';
import ToastContainer from '@/components/Toast';
import LocationProvider from '@/components/LocationProvider';

export default function LayoutShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const isCheckout = pathname?.startsWith('/checkout');
  const isAdmin = pathname?.startsWith('/admin');

  return (
    <>
      {/* Show navbar only when not on checkout or admin pages */}
      {!isCheckout && !isAdmin && <Navbar />}

      {/* Main area. For checkout, center and enlarge content for focus. */}
      {/* reduce top padding on checkout since Navbar is hidden there */}
      <main className={isCheckout ? 'min-h-screen bg-gray-50 pt-6' : 'min-h-screen'}>
        {children}
      </main>

      {/* Footer also hidden on checkout and admin pages */}
      {!isCheckout && !isAdmin && <Footer />}

      {/* Keep these global UI pieces available, but not location modal on admin */}
      <CartDrawer />
      <ToastContainer />
      {!isAdmin && <LocationProvider />}
    </>
  );
}
