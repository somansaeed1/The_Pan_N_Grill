# Quick Test Script for Pan-n-Grill API
# Run this after starting the server with: npm run server

# Test Variables (will be populated during tests)
$baseUrl = "http://localhost:5000"
$categoryId = ""
$productId = ""
$orderId = ""

Write-Host "`n🚀 Starting API Tests...`n" -ForegroundColor Cyan

# Test 1: Root endpoint
Write-Host "Test 1: GET / (Root endpoint)" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/" -Method Get
    Write-Host "✅ Success: $($response.message)" -ForegroundColor Green
} catch {
    Write-Host "❌ Failed: $_" -ForegroundColor Red
}

Write-Host "`n" + "="*60 + "`n" -ForegroundColor Gray

# Test 2: Create Category
Write-Host "Test 2: POST /api/categories (Create Category)" -ForegroundColor Yellow
try {
    $categoryBody = @{
        name = "Test Burgers"
        description = "Delicious test burgers"
        isActive = $true
        displayOrder = 1
    } | ConvertTo-Json

    $response = Invoke-RestMethod -Uri "$baseUrl/api/categories" -Method Post -Body $categoryBody -ContentType "application/json"
    $categoryId = $response.data._id
    Write-Host "✅ Created Category: $($response.data.name) (ID: $categoryId)" -ForegroundColor Green
} catch {
    Write-Host "❌ Failed: $_" -ForegroundColor Red
}

Write-Host "`n" + "="*60 + "`n" -ForegroundColor Gray

# Test 3: Get All Categories
Write-Host "Test 3: GET /api/categories (Get All Categories)" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/api/categories" -Method Get
    Write-Host "✅ Found $($response.count) categories" -ForegroundColor Green
} catch {
    Write-Host "❌ Failed: $_" -ForegroundColor Red
}

Write-Host "`n" + "="*60 + "`n" -ForegroundColor Gray

# Test 4: Create Product (requires category)
if ($categoryId) {
    Write-Host "Test 4: POST /api/products (Create Product)" -ForegroundColor Yellow
    try {
        $productBody = @{
            name = "Test Burger"
            description = "A delicious test burger"
            price = 12.99
            category = $categoryId
            isAvailable = $true
            spicyLevel = "mild"
        } | ConvertTo-Json

        $response = Invoke-RestMethod -Uri "$baseUrl/api/products" -Method Post -Body $productBody -ContentType "application/json"
        $productId = $response.data._id
        Write-Host "✅ Created Product: $($response.data.name) (ID: $productId)" -ForegroundColor Green
    } catch {
        Write-Host "❌ Failed: $_" -ForegroundColor Red
    }
} else {
    Write-Host "⏭️  Skipping: No category ID available" -ForegroundColor DarkYellow
}

Write-Host "`n" + "="*60 + "`n" -ForegroundColor Gray

# Test 5: Get All Products
Write-Host "Test 5: GET /api/products (Get All Products)" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/api/products" -Method Get
    Write-Host "✅ Found $($response.count) products" -ForegroundColor Green
} catch {
    Write-Host "❌ Failed: $_" -ForegroundColor Red
}

Write-Host "`n" + "="*60 + "`n" -ForegroundColor Gray

# Test 6: Create Order (requires product)
if ($productId) {
    Write-Host "Test 6: POST /api/orders (Create Order)" -ForegroundColor Yellow
    try {
        $orderBody = @{
            customerName = "Test Customer"
            customerEmail = "test@example.com"
            customerPhone = "+1234567890"
            items = @(
                @{
                    product = $productId
                    quantity = 2
                    price = 12.99
                }
            )
            totalAmount = 25.98
            orderType = "delivery"
            paymentMethod = "card"
        } | ConvertTo-Json -Depth 3

        $response = Invoke-RestMethod -Uri "$baseUrl/api/orders" -Method Post -Body $orderBody -ContentType "application/json"
        $orderId = $response.data._id
        Write-Host "✅ Created Order: $($response.data.orderNumber) (ID: $orderId)" -ForegroundColor Green
    } catch {
        Write-Host "❌ Failed: $_" -ForegroundColor Red
    }
} else {
    Write-Host "⏭️  Skipping: No product ID available" -ForegroundColor DarkYellow
}

Write-Host "`n" + "="*60 + "`n" -ForegroundColor Gray

# Test 7: Get All Orders
Write-Host "Test 7: GET /api/orders (Get All Orders)" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/api/orders" -Method Get
    Write-Host "✅ Found $($response.count) orders" -ForegroundColor Green
} catch {
    Write-Host "❌ Failed: $_" -ForegroundColor Red
}

Write-Host "`n" + "="*60 + "`n" -ForegroundColor Gray

# Test 8: Update Order
if ($orderId) {
    Write-Host "Test 8: PUT /api/orders/:id (Update Order)" -ForegroundColor Yellow
    try {
        $updateBody = @{
            status = "confirmed"
            paymentStatus = "paid"
        } | ConvertTo-Json

        $response = Invoke-RestMethod -Uri "$baseUrl/api/orders/$orderId" -Method Put -Body $updateBody -ContentType "application/json"
        Write-Host "✅ Updated Order Status: $($response.data.status)" -ForegroundColor Green
    } catch {
        Write-Host "❌ Failed: $_" -ForegroundColor Red
    }
}

Write-Host "`n" + "="*60 + "`n" -ForegroundColor Gray

# Test 9: Get Single Order
if ($orderId) {
    Write-Host "Test 9: GET /api/orders/:id (Get Single Order)" -ForegroundColor Yellow
    try {
        $response = Invoke-RestMethod -Uri "$baseUrl/api/orders/$orderId" -Method Get
        Write-Host "✅ Retrieved Order: $($response.data.orderNumber)" -ForegroundColor Green
    } catch {
        Write-Host "❌ Failed: $_" -ForegroundColor Red
    }
}

Write-Host "`n" + "="*60 + "`n" -ForegroundColor Gray

# Test 10: Delete Order
if ($orderId) {
    Write-Host "Test 10: DELETE /api/orders/:id (Delete Order)" -ForegroundColor Yellow
    try {
        $response = Invoke-RestMethod -Uri "$baseUrl/api/orders/$orderId" -Method Delete
        Write-Host "✅ Deleted Order Successfully" -ForegroundColor Green
    } catch {
        Write-Host "❌ Failed: $_" -ForegroundColor Red
    }
}

Write-Host "`n" + "="*60 + "`n" -ForegroundColor Gray

# Test 11: Delete Product
if ($productId) {
    Write-Host "Test 11: DELETE /api/products/:id (Delete Product)" -ForegroundColor Yellow
    try {
        $response = Invoke-RestMethod -Uri "$baseUrl/api/products/$productId" -Method Delete
        Write-Host "✅ Deleted Product Successfully" -ForegroundColor Green
    } catch {
        Write-Host "❌ Failed: $_" -ForegroundColor Red
    }
}

Write-Host "`n" + "="*60 + "`n" -ForegroundColor Gray

# Test 12: Delete Category
if ($categoryId) {
    Write-Host "Test 12: DELETE /api/categories/:id (Delete Category)" -ForegroundColor Yellow
    try {
        $response = Invoke-RestMethod -Uri "$baseUrl/api/categories/$categoryId" -Method Delete
        Write-Host "✅ Deleted Category Successfully" -ForegroundColor Green
    } catch {
        Write-Host "❌ Failed: $_" -ForegroundColor Red
    }
}

Write-Host "`n" + "="*60 + "`n" -ForegroundColor Gray
Write-Host "`n✨ All tests completed!`n" -ForegroundColor Cyan
Write-Host "📝 Note: For full 15-endpoint testing, use Postman with the POSTMAN_TESTING.md guide`n" -ForegroundColor Yellow
