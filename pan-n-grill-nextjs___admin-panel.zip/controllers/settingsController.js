const Settings = require('../models/Settings');

/**
 * @desc    Get restaurant settings
 * @route   GET /api/admin/settings
 * @access  Private (Admin)
 */
exports.getSettings = async (req, res) => {
  try {
    const settings = await Settings.getSettings();
    
    res.status(200).json({
      success: true,
      data: settings
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch settings',
      error: error.message
    });
  }
};

/**
 * @desc    Get public settings (for frontend)
 * @route   GET /api/settings/public
 * @access  Public
 */
exports.getPublicSettings = async (req, res) => {
  try {
    const settings = await Settings.getSettings();
    
    // Return only public-facing information
    const publicSettings = {
      restaurantName: settings.restaurantName,
      restaurantPhone: settings.restaurantPhone,
      restaurantEmail: settings.restaurantEmail,
      address: settings.address,
      operatingHours: settings.operatingHours,
      isOpen: settings.isOpen,
      closureReason: settings.closureReason,
      closedUntil: settings.closedUntil,
      taxRate: settings.taxRate,
      taxEnabled: settings.taxEnabled,
      deliveryFee: settings.deliveryFee,
      freeDeliveryThreshold: settings.freeDeliveryThreshold,
      minimumOrderAmount: settings.minimumOrderAmount,
      deliveryEnabled: settings.deliveryEnabled,
      acceptedPaymentMethods: settings.acceptedPaymentMethods,
      socialMedia: settings.socialMedia
    };
    
    res.status(200).json({
      success: true,
      data: publicSettings
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch public settings',
      error: error.message
    });
  }
};

/**
 * @desc    Update restaurant information
 * @route   PATCH /api/admin/settings/restaurant-info
 * @access  Private (Admin)
 */
exports.updateRestaurantInfo = async (req, res) => {
  try {
    const {
      restaurantName,
      restaurantPhone,
      restaurantEmail,
      address,
      operatingHours,
      socialMedia
    } = req.body;

    const settings = await Settings.getSettings();

    // Update fields if provided
    if (restaurantName) settings.restaurantName = restaurantName;
    if (restaurantPhone) settings.restaurantPhone = restaurantPhone;
    if (restaurantEmail) settings.restaurantEmail = restaurantEmail;
    if (address) settings.address = { ...settings.address, ...address };
    if (operatingHours) settings.operatingHours = { ...settings.operatingHours, ...operatingHours };
    if (socialMedia) settings.socialMedia = { ...settings.socialMedia, ...socialMedia };

    settings.lastUpdatedBy = req.user._id;
    await settings.save();

    res.status(200).json({
      success: true,
      message: 'Restaurant information updated successfully',
      data: settings
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: 'Failed to update restaurant information',
      error: error.message
    });
  }
};

/**
 * @desc    Update tax settings
 * @route   PATCH /api/admin/settings/tax
 * @access  Private (Admin)
 */
exports.updateTaxSettings = async (req, res) => {
  try {
    const { taxRate, taxEnabled } = req.body;

    if (taxRate !== undefined && (taxRate < 0 || taxRate > 100)) {
      return res.status(400).json({
        success: false,
        message: 'Tax rate must be between 0 and 100'
      });
    }

    const settings = await Settings.getSettings();

    if (taxRate !== undefined) settings.taxRate = taxRate;
    if (taxEnabled !== undefined) settings.taxEnabled = taxEnabled;

    settings.lastUpdatedBy = req.user._id;
    await settings.save();

    res.status(200).json({
      success: true,
      message: 'Tax settings updated successfully',
      data: {
        taxRate: settings.taxRate,
        taxEnabled: settings.taxEnabled
      }
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: 'Failed to update tax settings',
      error: error.message
    });
  }
};

/**
 * @desc    Update delivery settings
 * @route   PATCH /api/admin/settings/delivery
 * @access  Private (Admin)
 */
exports.updateDeliverySettings = async (req, res) => {
  try {
    const {
      deliveryFee,
      freeDeliveryThreshold,
      minimumOrderAmount,
      deliveryEnabled,
      deliveryRadius
    } = req.body;

    // Validate values
    if (deliveryFee !== undefined && deliveryFee < 0) {
      return res.status(400).json({
        success: false,
        message: 'Delivery fee must be at least 0'
      });
    }

    if (minimumOrderAmount !== undefined && minimumOrderAmount < 0) {
      return res.status(400).json({
        success: false,
        message: 'Minimum order amount must be at least 0'
      });
    }

    if (freeDeliveryThreshold !== undefined && freeDeliveryThreshold < 0) {
      return res.status(400).json({
        success: false,
        message: 'Free delivery threshold must be at least 0'
      });
    }

    if (deliveryRadius !== undefined && deliveryRadius < 0) {
      return res.status(400).json({
        success: false,
        message: 'Delivery radius must be positive'
      });
    }

    const settings = await Settings.getSettings();

    if (deliveryFee !== undefined) settings.deliveryFee = deliveryFee;
    if (freeDeliveryThreshold !== undefined) settings.freeDeliveryThreshold = freeDeliveryThreshold;
    if (minimumOrderAmount !== undefined) settings.minimumOrderAmount = minimumOrderAmount;
    if (deliveryEnabled !== undefined) settings.deliveryEnabled = deliveryEnabled;
    if (deliveryRadius !== undefined) settings.deliveryRadius = deliveryRadius;

    settings.lastUpdatedBy = req.user._id;
    await settings.save();

    res.status(200).json({
      success: true,
      message: 'Delivery settings updated successfully',
      data: {
        deliveryFee: settings.deliveryFee,
        freeDeliveryThreshold: settings.freeDeliveryThreshold,
        minimumOrderAmount: settings.minimumOrderAmount,
        deliveryEnabled: settings.deliveryEnabled,
        deliveryRadius: settings.deliveryRadius
      }
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: 'Failed to update delivery settings',
      error: error.message
    });
  }
};

/**
 * @desc    Toggle restaurant open/close status
 * @route   PATCH /api/admin/settings/toggle-status
 * @access  Private (Admin)
 */
exports.toggleRestaurantStatus = async (req, res) => {
  try {
    const { isOpen, reason, closedUntil } = req.body;

    if (typeof isOpen !== 'boolean') {
      return res.status(400).json({
        success: false,
        message: 'isOpen must be a boolean value'
      });
    }

    // Validate closedUntil date if provided
    if (closedUntil && !isOpen) {
      const closedDate = new Date(closedUntil);
      if (closedDate <= new Date()) {
        return res.status(400).json({
          success: false,
          message: 'closedUntil date must be in the future'
        });
      }
    }

    const settings = await Settings.getSettings();

    settings.toggleOpenStatus(isOpen, reason, closedUntil);
    settings.lastUpdatedBy = req.user._id;
    await settings.save();

    res.status(200).json({
      success: true,
      message: `Restaurant ${isOpen ? 'opened' : 'closed'} successfully`,
      data: {
        isOpen: settings.isOpen,
        closureReason: settings.closureReason,
        closedUntil: settings.closedUntil
      }
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: 'Failed to toggle restaurant status',
      error: error.message
    });
  }
};

/**
 * @desc    Update payment settings
 * @route   PATCH /api/admin/settings/payment
 * @access  Private (Admin)
 */
exports.updatePaymentSettings = async (req, res) => {
  try {
    const { acceptedPaymentMethods } = req.body;

    if (!acceptedPaymentMethods) {
      return res.status(400).json({
        success: false,
        message: 'Please provide acceptedPaymentMethods'
      });
    }

    const settings = await Settings.getSettings();

    settings.acceptedPaymentMethods = {
      ...settings.acceptedPaymentMethods,
      ...acceptedPaymentMethods
    };

    settings.lastUpdatedBy = req.user._id;
    await settings.save();

    res.status(200).json({
      success: true,
      message: 'Payment settings updated successfully',
      data: {
        acceptedPaymentMethods: settings.acceptedPaymentMethods
      }
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: 'Failed to update payment settings',
      error: error.message
    });
  }
};

/**
 * @desc    Update notification settings
 * @route   PATCH /api/admin/settings/notifications
 * @access  Private (Admin)
 */
exports.updateNotificationSettings = async (req, res) => {
  try {
    const { notifications } = req.body;

    if (!notifications) {
      return res.status(400).json({
        success: false,
        message: 'Please provide notifications settings'
      });
    }

    const settings = await Settings.getSettings();

    if (notifications.email) {
      settings.notifications.email = {
        ...settings.notifications.email,
        ...notifications.email
      };
    }

    if (notifications.sms) {
      settings.notifications.sms = {
        ...settings.notifications.sms,
        ...notifications.sms
      };
    }

    settings.lastUpdatedBy = req.user._id;
    await settings.save();

    res.status(200).json({
      success: true,
      message: 'Notification settings updated successfully',
      data: {
        notifications: settings.notifications
      }
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: 'Failed to update notification settings',
      error: error.message
    });
  }
};

/**
 * @desc    Update operating hours
 * @route   PATCH /api/admin/settings/operating-hours
 * @access  Private (Admin)
 */
exports.updateOperatingHours = async (req, res) => {
  try {
    const { operatingHours } = req.body;

    if (!operatingHours) {
      return res.status(400).json({
        success: false,
        message: 'Please provide operating hours'
      });
    }

    const settings = await Settings.getSettings();

    settings.operatingHours = {
      ...settings.operatingHours,
      ...operatingHours
    };

    settings.lastUpdatedBy = req.user._id;
    await settings.save();

    res.status(200).json({
      success: true,
      message: 'Operating hours updated successfully',
      data: {
        operatingHours: settings.operatingHours
      }
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: 'Failed to update operating hours',
      error: error.message
    });
  }
};
