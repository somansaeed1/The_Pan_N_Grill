const Order = require('../models/Order');
const Product = require('../models/Product');
const Category = require('../models/Category');

/**
 * @desc    Get dashboard statistics
 * @route   GET /api/admin/dashboard/stats
 * @access  Private (Admin)
 */
exports.getDashboardStats = async (req, res) => {
  try {
    // Get total orders count
    const totalOrders = await Order.countDocuments();

    // Get total revenue using aggregation
    const revenueResult = await Order.aggregate([
      {
        $group: {
          _id: null,
          totalRevenue: { $sum: '$totalAmount' }
        }
      }
    ]);
    const totalRevenue = revenueResult.length > 0 ? revenueResult[0].totalRevenue : 0;

    // Get active orders (pending, confirmed, preparing)
    const activeOrdersCount = await Order.countDocuments({
      status: { $in: ['pending', 'confirmed', 'preparing'] }
    });

    // Get top 5 products by order frequency
    const topProducts = await Order.aggregate([
      { $unwind: '$items' },
      {
        $group: {
          _id: '$items.product',
          orderCount: { $sum: 1 },
          totalQuantity: { $sum: '$items.quantity' },
          totalRevenue: { $sum: { $multiply: ['$items.price', '$items.quantity'] } }
        }
      },
      { $sort: { orderCount: -1 } },
      { $limit: 5 },
      {
        $lookup: {
          from: 'products',
          localField: '_id',
          foreignField: '_id',
          as: 'productDetails'
        }
      },
      { $unwind: '$productDetails' },
      {
        $project: {
          _id: 0,
          productId: '$_id',
          name: '$productDetails.name',
          image: '$productDetails.image',
          price: '$productDetails.price',
          orderCount: 1,
          totalQuantity: 1,
          totalRevenue: 1
        }
      }
    ]);

    res.status(200).json({
      success: true,
      data: {
        totalOrders,
        totalRevenue: parseFloat(totalRevenue.toFixed(2)),
        activeOrders: activeOrdersCount,
        topProducts
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch dashboard statistics',
      error: error.message
    });
  }
};

/**
 * @desc    Get recent orders
 * @route   GET /api/admin/dashboard/recent-orders
 * @access  Private (Admin)
 */
exports.getRecentOrders = async (req, res) => {
  try {
    const { limit = 10 } = req.query;

    const recentOrders = await Order.find()
      .populate('items.product', 'name image price')
      .sort({ createdAt: -1 })
      .limit(parseInt(limit))
      .select('orderNumber customerName totalAmount status orderType createdAt');

    res.status(200).json({
      success: true,
      count: recentOrders.length,
      data: recentOrders
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch recent orders',
      error: error.message
    });
  }
};

/**
 * @desc    Get revenue statistics by period
 * @route   GET /api/admin/dashboard/revenue-stats
 * @access  Private (Admin)
 */
exports.getRevenueStats = async (req, res) => {
  try {
    const { period = 'month' } = req.query; // day, week, month, year

    let groupBy;
    let startDate = new Date();

    switch (period) {
      case 'day':
        groupBy = {
          year: { $year: '$createdAt' },
          month: { $month: '$createdAt' },
          day: { $dayOfMonth: '$createdAt' }
        };
        startDate.setDate(startDate.getDate() - 30); // Last 30 days
        break;
      case 'week':
        groupBy = {
          year: { $year: '$createdAt' },
          week: { $week: '$createdAt' }
        };
        startDate.setDate(startDate.getDate() - 90); // Last 90 days
        break;
      case 'month':
        groupBy = {
          year: { $year: '$createdAt' },
          month: { $month: '$createdAt' }
        };
        startDate.setFullYear(startDate.getFullYear() - 1); // Last year
        break;
      case 'year':
        groupBy = {
          year: { $year: '$createdAt' }
        };
        startDate.setFullYear(startDate.getFullYear() - 5); // Last 5 years
        break;
      default:
        groupBy = {
          year: { $year: '$createdAt' },
          month: { $month: '$createdAt' }
        };
        startDate.setFullYear(startDate.getFullYear() - 1);
    }

    const revenueStats = await Order.aggregate([
      {
        $match: {
          createdAt: { $gte: startDate }
        }
      },
      {
        $group: {
          _id: groupBy,
          totalRevenue: { $sum: '$totalAmount' },
          orderCount: { $sum: 1 },
          averageOrderValue: { $avg: '$totalAmount' }
        }
      },
      { $sort: { '_id.year': 1, '_id.month': 1, '_id.week': 1, '_id.day': 1 } }
    ]);

    res.status(200).json({
      success: true,
      period,
      count: revenueStats.length,
      data: revenueStats
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch revenue statistics',
      error: error.message
    });
  }
};

/**
 * @desc    Get order status distribution
 * @route   GET /api/admin/dashboard/order-status
 * @access  Private (Admin)
 */
exports.getOrderStatusDistribution = async (req, res) => {
  try {
    const statusDistribution = await Order.aggregate([
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 },
          totalAmount: { $sum: '$totalAmount' }
        }
      },
      {
        $project: {
          _id: 0,
          status: '$_id',
          count: 1,
          totalAmount: 1
        }
      },
      { $sort: { count: -1 } }
    ]);

    res.status(200).json({
      success: true,
      data: statusDistribution
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch order status distribution',
      error: error.message
    });
  }
};

/**
 * @desc    Get category performance
 * @route   GET /api/admin/dashboard/category-performance
 * @access  Private (Admin)
 */
exports.getCategoryPerformance = async (req, res) => {
  try {
    const categoryPerformance = await Order.aggregate([
      { $unwind: '$items' },
      {
        $lookup: {
          from: 'products',
          localField: 'items.product',
          foreignField: '_id',
          as: 'productInfo'
        }
      },
      { $unwind: '$productInfo' },
      {
        $lookup: {
          from: 'categories',
          localField: 'productInfo.category',
          foreignField: '_id',
          as: 'categoryInfo'
        }
      },
      { $unwind: '$categoryInfo' },
      {
        $group: {
          _id: '$categoryInfo._id',
          categoryName: { $first: '$categoryInfo.name' },
          totalOrders: { $sum: 1 },
          totalQuantity: { $sum: '$items.quantity' },
          totalRevenue: { $sum: { $multiply: ['$items.price', '$items.quantity'] } }
        }
      },
      { $sort: { totalRevenue: -1 } }
    ]);

    res.status(200).json({
      success: true,
      data: categoryPerformance
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch category performance',
      error: error.message
    });
  }
};

/**
 * @desc    Get overall summary
 * @route   GET /api/admin/dashboard/summary
 * @access  Private (Admin)
 */
exports.getOverallSummary = async (req, res) => {
  try {
    // Run all queries in parallel for better performance
    const [
      totalOrders,
      totalProducts,
      totalCategories,
      revenueData,
      activeOrders,
      todayOrders
    ] = await Promise.all([
      Order.countDocuments(),
      Product.countDocuments(),
      Category.countDocuments(),
      Order.aggregate([
        {
          $group: {
            _id: null,
            totalRevenue: { $sum: '$totalAmount' },
            averageOrderValue: { $avg: '$totalAmount' }
          }
        }
      ]),
      Order.countDocuments({
        status: { $in: ['pending', 'confirmed', 'preparing'] }
      }),
      Order.countDocuments({
        createdAt: {
          $gte: new Date(new Date().setHours(0, 0, 0, 0))
        }
      })
    ]);

    const revenue = revenueData.length > 0 ? revenueData[0] : { totalRevenue: 0, averageOrderValue: 0 };

    res.status(200).json({
      success: true,
      data: {
        totalOrders,
        totalProducts,
        totalCategories,
        totalRevenue: parseFloat(revenue.totalRevenue.toFixed(2)),
        averageOrderValue: parseFloat(revenue.averageOrderValue.toFixed(2)),
        activeOrders,
        todayOrders
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch overall summary',
      error: error.message
    });
  }
};
