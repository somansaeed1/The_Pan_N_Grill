const AdminLog = require('../models/AdminLog');

/**
 * @desc    Get all activity logs with filters
 * @route   GET /api/admin/activity-logs
 * @access  Private (Admin)
 */
exports.getAllLogs = async (req, res) => {
  try {
    const {
      admin,
      resourceType,
      action,
      startDate,
      endDate,
      page = 1,
      limit = 50
    } = req.query;

    const result = await AdminLog.getFilteredLogs({
      admin,
      resourceType,
      action,
      startDate,
      endDate
    }, {
      page,
      limit
    });

    res.status(200).json({
      success: true,
      count: result.logs.length,
      ...result.pagination,
      data: result.logs
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch activity logs',
      error: error.message
    });
  }
};

/**
 * @desc    Get activity logs for specific admin
 * @route   GET /api/admin/activity-logs/admin/:adminId
 * @access  Private (Admin)
 */
exports.getLogsByAdmin = async (req, res) => {
  try {
    const {
      resourceType,
      action,
      startDate,
      endDate,
      page = 1,
      limit = 50
    } = req.query;

    const result = await AdminLog.getFilteredLogs({
      admin: req.params.adminId,
      resourceType,
      action,
      startDate,
      endDate
    }, {
      page,
      limit
    });

    res.status(200).json({
      success: true,
      count: result.logs.length,
      ...result.pagination,
      data: result.logs
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch admin activity logs',
      error: error.message
    });
  }
};

/**
 * @desc    Get activity logs for specific resource
 * @route   GET /api/admin/activity-logs/resource/:resourceType/:resourceId
 * @access  Private (Admin)
 */
exports.getLogsByResource = async (req, res) => {
  try {
    const { resourceType, resourceId } = req.params;
    const { page = 1, limit = 50 } = req.query;

    const skip = (page - 1) * limit;

    const logs = await AdminLog.find({
      resourceType,
      resourceId
    })
      .populate('admin', 'name email role')
      .sort({ createdAt: -1 })
      .limit(parseInt(limit))
      .skip(skip);

    const total = await AdminLog.countDocuments({
      resourceType,
      resourceId
    });

    res.status(200).json({
      success: true,
      count: logs.length,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit),
      data: logs
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch resource activity logs',
      error: error.message
    });
  }
};

/**
 * @desc    Get current admin's activity logs
 * @route   GET /api/admin/activity-logs/me
 * @access  Private (Admin)
 */
exports.getMyLogs = async (req, res) => {
  try {
    const {
      resourceType,
      action,
      startDate,
      endDate,
      page = 1,
      limit = 50
    } = req.query;

    const result = await AdminLog.getFilteredLogs({
      admin: req.user._id,
      resourceType,
      action,
      startDate,
      endDate
    }, {
      page,
      limit
    });

    res.status(200).json({
      success: true,
      count: result.logs.length,
      ...result.pagination,
      data: result.logs
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch your activity logs',
      error: error.message
    });
  }
};

/**
 * @desc    Get activity statistics
 * @route   GET /api/admin/activity-logs/stats
 * @access  Private (Admin)
 */
exports.getActivityStats = async (req, res) => {
  try {
    const { startDate, endDate } = req.query;

    const dateFilter = {};
    if (startDate || endDate) {
      dateFilter.createdAt = {};
      if (startDate) dateFilter.createdAt.$gte = new Date(startDate);
      if (endDate) dateFilter.createdAt.$lte = new Date(endDate);
    }

    // Total activities
    const totalActivities = await AdminLog.countDocuments(dateFilter);

    // Activities by admin
    const activitiesByAdmin = await AdminLog.aggregate([
      { $match: dateFilter },
      {
        $group: {
          _id: '$admin',
          count: { $sum: 1 }
        }
      },
      {
        $lookup: {
          from: 'admins',
          localField: '_id',
          foreignField: '_id',
          as: 'adminInfo'
        }
      },
      {
        $unwind: '$adminInfo'
      },
      {
        $project: {
          _id: 1,
          name: '$adminInfo.name',
          email: '$adminInfo.email',
          role: '$adminInfo.role',
          activityCount: '$count'
        }
      },
      { $sort: { activityCount: -1 } },
      { $limit: 10 }
    ]);

    // Activities by resource type
    const activitiesByResource = await AdminLog.aggregate([
      { $match: dateFilter },
      {
        $group: {
          _id: '$resourceType',
          count: { $sum: 1 }
        }
      },
      { $sort: { count: -1 } }
    ]);

    // Activities by method
    const activitiesByMethod = await AdminLog.aggregate([
      { $match: dateFilter },
      {
        $group: {
          _id: '$method',
          count: { $sum: 1 }
        }
      },
      { $sort: { count: -1 } }
    ]);

    // Recent activities
    const recentActivities = await AdminLog.find(dateFilter)
      .populate('admin', 'name email role')
      .sort({ createdAt: -1 })
      .limit(10);

    // Success rate
    const successCount = await AdminLog.countDocuments({
      ...dateFilter,
      success: true
    });

    const successRate = totalActivities > 0 
      ? ((successCount / totalActivities) * 100).toFixed(2) 
      : 0;

    res.status(200).json({
      success: true,
      data: {
        totalActivities,
        successRate: parseFloat(successRate),
        activitiesByAdmin,
        activitiesByResource,
        activitiesByMethod,
        recentActivities
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch activity statistics',
      error: error.message
    });
  }
};

/**
 * @desc    Get recent activity logs
 * @route   GET /api/admin/activity-logs/recent
 * @access  Private (Admin)
 */
exports.getRecentLogs = async (req, res) => {
  try {
    const { limit = 20 } = req.query;

    const logs = await AdminLog.find()
      .populate('admin', 'name email role')
      .sort({ createdAt: -1 })
      .limit(parseInt(limit));

    res.status(200).json({
      success: true,
      count: logs.length,
      data: logs
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch recent activity logs',
      error: error.message
    });
  }
};

/**
 * @desc    Delete old activity logs
 * @route   DELETE /api/admin/activity-logs/cleanup
 * @access  Private (Super Admin only)
 */
exports.cleanupOldLogs = async (req, res) => {
  try {
    const { days = 90 } = req.query;

    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - parseInt(days));

    const result = await AdminLog.deleteMany({
      createdAt: { $lt: cutoffDate }
    });

    res.status(200).json({
      success: true,
      message: `Deleted logs older than ${days} days`,
      deletedCount: result.deletedCount
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to cleanup activity logs',
      error: error.message
    });
  }
};
