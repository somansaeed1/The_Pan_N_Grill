const Product = require('../models/Product');
const Category = require('../models/Category');

/**
 * Input validation helper
 */
const validateProductInput = (data) => {
  const errors = [];

  // Name validation
  if (!data.name || data.name.trim().length < 2) {
    errors.push('Product name must be at least 2 characters long');
  }
  if (data.name && data.name.length > 100) {
    errors.push('Product name must not exceed 100 characters');
  }

  // Price validation
  if (data.price === undefined || data.price === null) {
    errors.push('Product price is required');
  }
  if (data.price !== undefined && data.price < 0) {
    errors.push('Price must be a positive number');
  }

  // Category validation
  if (!data.category) {
    errors.push('Product category is required');
  }

  // Description validation
  if (data.description && data.description.length > 1000) {
    errors.push('Description must not exceed 1000 characters');
  }

  // Spicy level validation
  const validSpicyLevels = ['none', 'mild', 'medium', 'hot', 'extra-hot'];
  if (data.spicyLevel && !validSpicyLevels.includes(data.spicyLevel)) {
    errors.push(`Spicy level must be one of: ${validSpicyLevels.join(', ')}`);
  }

  // Preparation time validation
  if (data.preparationTime !== undefined && data.preparationTime < 0) {
    errors.push('Preparation time must be positive');
  }

  // Calories validation
  if (data.calories !== undefined && data.calories < 0) {
    errors.push('Calories must be positive');
  }

  return errors;
};

/**
 * @desc    Create a new product
 * @route   POST /api/products
 * @access  Private (Admin)
 */
exports.createProduct = async (req, res) => {
  try {
    // Validate input
    const validationErrors = validateProductInput(req.body);
    if (validationErrors.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: validationErrors
      });
    }

    // Check if category exists
    const categoryExists = await Category.findById(req.body.category);
    if (!categoryExists) {
      return res.status(404).json({
        success: false,
        message: 'Category not found'
      });
    }

    // Create product
    const product = await Product.create(req.body);
    const populatedProduct = await Product.findById(product._id).populate('category');

    res.status(201).json({
      success: true,
      message: 'Product created successfully',
      data: populatedProduct
    });
  } catch (error) {
    // Handle duplicate key error
    if (error.code === 11000) {
      return res.status(409).json({
        success: false,
        message: 'A product with similar details already exists'
      });
    }

    // Handle validation errors from Mongoose
    if (error.name === 'ValidationError') {
      const errors = Object.values(error.errors).map(err => err.message);
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors
      });
    }

    res.status(500).json({
      success: false,
      message: 'Failed to create product',
      error: error.message
    });
  }
};

/**
 * @desc    Get all products
 * @route   GET /api/products
 * @access  Public
 */
exports.getAllProducts = async (req, res) => {
  try {
    const { category, isAvailable, isVegetarian, spicyLevel, includeDeleted } = req.query;

    // Build query
    let query = {};
    
    if (category) query.category = category;
    if (isAvailable !== undefined) query.isAvailable = isAvailable === 'true';
    if (isVegetarian !== undefined) query.isVegetarian = isVegetarian === 'true';
    if (spicyLevel) query.spicyLevel = spicyLevel;

    // Options for including soft-deleted products
    const options = includeDeleted === 'true' ? { includeDeleted: true } : {};

    const products = await Product.find(query, null, options).populate('category').sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: products.length,
      data: products
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch products',
      error: error.message
    });
  }
};

/**
 * @desc    Get single product by ID
 * @route   GET /api/products/:id
 * @access  Public
 */
exports.getProductById = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id).populate('category');

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    res.status(200).json({
      success: true,
      data: product
    });
  } catch (error) {
    // Handle invalid ObjectId
    if (error.kind === 'ObjectId') {
      return res.status(400).json({
        success: false,
        message: 'Invalid product ID format'
      });
    }

    res.status(500).json({
      success: false,
      message: 'Failed to fetch product',
      error: error.message
    });
  }
};

/**
 * @desc    Update product
 * @route   PUT /api/products/:id
 * @access  Private (Admin)
 */
exports.updateProduct = async (req, res) => {
  try {
    // Validate input
    const validationErrors = validateProductInput(req.body);
    if (validationErrors.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: validationErrors
      });
    }

    // Check if product exists
    const existingProduct = await Product.findById(req.params.id);
    if (!existingProduct) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    // Check if category exists (if being updated)
    if (req.body.category) {
      const categoryExists = await Category.findById(req.body.category);
      if (!categoryExists) {
        return res.status(404).json({
          success: false,
          message: 'Category not found'
        });
      }
    }

    // Prevent modification of soft-delete fields through this endpoint
    delete req.body.isDeleted;
    delete req.body.deletedAt;

    // Update product
    const product = await Product.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    ).populate('category');

    res.status(200).json({
      success: true,
      message: 'Product updated successfully',
      data: product
    });
  } catch (error) {
    // Handle invalid ObjectId
    if (error.kind === 'ObjectId') {
      return res.status(400).json({
        success: false,
        message: 'Invalid product ID format'
      });
    }

    // Handle validation errors
    if (error.name === 'ValidationError') {
      const errors = Object.values(error.errors).map(err => err.message);
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors
      });
    }

    res.status(500).json({
      success: false,
      message: 'Failed to update product',
      error: error.message
    });
  }
};

/**
 * @desc    Soft delete product
 * @route   DELETE /api/products/:id
 * @access  Private (Admin)
 */
exports.deleteProduct = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    // Check if already deleted
    if (product.isDeleted) {
      return res.status(400).json({
        success: false,
        message: 'Product is already deleted'
      });
    }

    // Soft delete
    await product.softDelete();

    res.status(200).json({
      success: true,
      message: 'Product deleted successfully',
      data: {
        id: product._id,
        name: product.name,
        deletedAt: product.deletedAt
      }
    });
  } catch (error) {
    // Handle invalid ObjectId
    if (error.kind === 'ObjectId') {
      return res.status(400).json({
        success: false,
        message: 'Invalid product ID format'
      });
    }

    res.status(500).json({
      success: false,
      message: 'Failed to delete product',
      error: error.message
    });
  }
};

/**
 * @desc    Toggle product availability
 * @route   PATCH /api/products/:id/availability
 * @access  Private (Admin)
 */
exports.toggleAvailability = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    // Cannot make deleted products available
    if (product.isDeleted) {
      return res.status(400).json({
        success: false,
        message: 'Cannot modify availability of deleted products'
      });
    }

    // Toggle availability
    product.isAvailable = !product.isAvailable;
    await product.save();

    const populatedProduct = await Product.findById(product._id).populate('category');

    res.status(200).json({
      success: true,
      message: `Product ${product.isAvailable ? 'is now available' : 'is now unavailable'}`,
      data: populatedProduct
    });
  } catch (error) {
    // Handle invalid ObjectId
    if (error.kind === 'ObjectId') {
      return res.status(400).json({
        success: false,
        message: 'Invalid product ID format'
      });
    }

    res.status(500).json({
      success: false,
      message: 'Failed to toggle product availability',
      error: error.message
    });
  }
};

/**
 * @desc    Restore soft-deleted product
 * @route   PATCH /api/products/:id/restore
 * @access  Private (Admin)
 */
exports.restoreProduct = async (req, res) => {
  try {
    // Include deleted products in query
    const product = await Product.findById(req.params.id).select('+isDeleted +deletedAt');

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    if (!product.isDeleted) {
      return res.status(400).json({
        success: false,
        message: 'Product is not deleted'
      });
    }

    // Restore product
    await product.restore();
    const populatedProduct = await Product.findById(product._id).populate('category');

    res.status(200).json({
      success: true,
      message: 'Product restored successfully',
      data: populatedProduct
    });
  } catch (error) {
    // Handle invalid ObjectId
    if (error.kind === 'ObjectId') {
      return res.status(400).json({
        success: false,
        message: 'Invalid product ID format'
      });
    }

    res.status(500).json({
      success: false,
      message: 'Failed to restore product',
      error: error.message
    });
  }
};

/**
 * @desc    Permanently delete product
 * @route   DELETE /api/products/:id/permanent
 * @access  Private (Super Admin only)
 */
exports.permanentDeleteProduct = async (req, res) => {
  try {
    const product = await Product.findByIdAndDelete(req.params.id);

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    res.status(200).json({
      success: true,
      message: 'Product permanently deleted',
      data: {
        id: product._id,
        name: product.name
      }
    });
  } catch (error) {
    // Handle invalid ObjectId
    if (error.kind === 'ObjectId') {
      return res.status(400).json({
        success: false,
        message: 'Invalid product ID format'
      });
    }

    res.status(500).json({
      success: false,
      message: 'Failed to permanently delete product',
      error: error.message
    });
  }
};

/**
 * @desc    Bulk update product availability
 * @route   PATCH /api/products/bulk/availability
 * @access  Private (Admin)
 */
exports.bulkUpdateAvailability = async (req, res) => {
  try {
    const { productIds, isAvailable } = req.body;

    if (!Array.isArray(productIds) || productIds.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Please provide an array of product IDs'
      });
    }

    if (typeof isAvailable !== 'boolean') {
      return res.status(400).json({
        success: false,
        message: 'isAvailable must be a boolean value'
      });
    }

    // Update multiple products
    const result = await Product.updateMany(
      { 
        _id: { $in: productIds },
        isDeleted: { $ne: true }
      },
      { isAvailable }
    );

    res.status(200).json({
      success: true,
      message: `${result.modifiedCount} products updated`,
      data: {
        matchedCount: result.matchedCount,
        modifiedCount: result.modifiedCount
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to bulk update products',
      error: error.message
    });
  }
};

/**
 * @desc    Upload product image
 * @route   POST /api/products/:id/upload-image
 * @access  Private (Admin)
 */
exports.uploadProductImage = async (req, res) => {
  try {
    // Check if file was uploaded
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'No image file uploaded'
      });
    }

    // Find product
    const product = await Product.findById(req.params.id);

    if (!product) {
      // Delete uploaded file if product not found
      const fs = require('fs');
      const path = require('path');
      const filePath = path.join(__dirname, '..', req.file.path);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }

      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    // Check if product is deleted
    if (product.isDeleted) {
      // Delete uploaded file
      const fs = require('fs');
      const path = require('path');
      const filePath = path.join(__dirname, '..', req.file.path);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }

      return res.status(400).json({
        success: false,
        message: 'Cannot upload image for deleted products'
      });
    }

    // Store old image path for cleanup
    const oldImage = product.image;

    // Update product with new image URL
    product.image = `/uploads/products/${req.file.filename}`;
    await product.save();

    // Delete old image if it exists
    if (oldImage && oldImage.startsWith('/uploads/')) {
      const fs = require('fs');
      const path = require('path');
      const oldImagePath = path.join(__dirname, '..', oldImage);
      if (fs.existsSync(oldImagePath)) {
        try {
          fs.unlinkSync(oldImagePath);
        } catch (err) {
          console.error('Error deleting old image:', err);
        }
      }
    }

    const populatedProduct = await Product.findById(product._id).populate('category');

    res.status(200).json({
      success: true,
      message: 'Image uploaded successfully',
      data: {
        product: populatedProduct,
        image: {
          filename: req.file.filename,
          path: product.image,
          url: `${req.protocol}://${req.get('host')}${product.image}`,
          size: req.file.size,
          mimetype: req.file.mimetype
        }
      }
    });
  } catch (error) {
    // Clean up uploaded file on error
    if (req.file) {
      const fs = require('fs');
      const path = require('path');
      const filePath = path.join(__dirname, '..', req.file.path);
      if (fs.existsSync(filePath)) {
        try {
          fs.unlinkSync(filePath);
        } catch (err) {
          console.error('Error deleting file:', err);
        }
      }
    }

    // Handle invalid ObjectId
    if (error.kind === 'ObjectId') {
      return res.status(400).json({
        success: false,
        message: 'Invalid product ID format'
      });
    }

    res.status(500).json({
      success: false,
      message: 'Failed to upload image',
      error: error.message
    });
  }
};

/**
 * @desc    Delete product image
 * @route   DELETE /api/products/:id/image
 * @access  Private (Admin)
 */
exports.deleteProductImage = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    if (!product.image) {
      return res.status(400).json({
        success: false,
        message: 'Product has no image to delete'
      });
    }

    const imagePath = product.image;

    // Remove image from filesystem
    if (imagePath.startsWith('/uploads/')) {
      const fs = require('fs');
      const path = require('path');
      const fullPath = path.join(__dirname, '..', imagePath);
      
      if (fs.existsSync(fullPath)) {
        try {
          fs.unlinkSync(fullPath);
        } catch (err) {
          console.error('Error deleting image file:', err);
        }
      }
    }

    // Remove image URL from product
    product.image = undefined;
    await product.save();

    const populatedProduct = await Product.findById(product._id).populate('category');

    res.status(200).json({
      success: true,
      message: 'Product image deleted successfully',
      data: populatedProduct
    });
  } catch (error) {
    // Handle invalid ObjectId
    if (error.kind === 'ObjectId') {
      return res.status(400).json({
        success: false,
        message: 'Invalid product ID format'
      });
    }

    res.status(500).json({
      success: false,
      message: 'Failed to delete image',
      error: error.message
    });
  }
};
