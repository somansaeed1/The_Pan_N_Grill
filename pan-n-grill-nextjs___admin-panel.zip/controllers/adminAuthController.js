const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const Admin = require('../models/Admin');

/**
 * @desc    Admin login
 * @route   POST /api/admin/auth/login
 * @access  Public
 */
exports.login = async (req, res) => {
  try {
    const { username, emailOrUsername, password } = req.body;

    // Support both old 'username' field and new 'emailOrUsername' field
    const loginIdentifier = emailOrUsername || username;

    // Validate input
    if (!loginIdentifier || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide email/username and password'
      });
    }

    // Find admin by username or email
    const admin = await Admin.findOne({ 
      $or: [
        { username: loginIdentifier },
        { email: loginIdentifier }
      ]
    }).select('+password');
    
    // Verify credentials
    if (!admin || !(await admin.comparePassword(password))) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email/username or password'
      });
    }

    // Check if admin is active
    if (!admin.isActive) {
      return res.status(401).json({
        success: false,
        message: 'Your account has been deactivated. Please contact support.'
      });
    }

    // Update last login timestamp
    admin.lastLogin = new Date();
    await admin.save({ validateBeforeSave: false });

    // Generate JWT tokens
    const token = admin.generateAuthToken();
    const refreshToken = admin.generateRefreshToken();

    // Save refresh token to database
    admin.refreshToken = refreshToken;
    await admin.save({ validateBeforeSave: false });

    // Remove sensitive data from response
    admin.password = undefined;
    admin.refreshToken = undefined;

    res.status(200).json({
      success: true,
      message: 'Login successful',
      data: {
        admin,
        token,
        refreshToken
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Login failed',
      error: error.message
    });
  }
};

/**
 * @desc    Admin public signup
 * @route   POST /api/admin/auth/public-signup
 * @access  Public
 */
exports.publicSignup = async (req, res) => {
  try {
    const { username, email, password, fullName } = req.body;

    // Validate required fields
    if (!username || !email || !password || !fullName) {
      return res.status(400).json({
        success: false,
        message: 'Please provide all required fields'
      });
    }

    // Check if admin already exists
    const existingAdmin = await Admin.findOne({ $or: [{ email }, { username }] });
    if (existingAdmin) {
      return res.status(400).json({
        success: false,
        message: 'Admin with this email or username already exists'
      });
    }

    // Create new admin with default 'admin' role
    const admin = await Admin.create({
      username,
      email,
      password,
      fullName,
      role: 'admin'
    });

    // Remove password from output
    admin.password = undefined;

    res.status(201).json({
      success: true,
      message: 'Admin account created successfully',
      data: admin
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: 'Failed to create admin account',
      error: error.message
    });
  }
};

/**
 * @desc    Create admin (super-admin only)
 * @route   POST /api/admin/auth/signup
 * @access  Private (super-admin)
 */
exports.createAdmin = async (req, res) => {
  try {
    const { username, email, password, fullName, role } = req.body;

    // Validate required fields
    if (!username || !email || !password || !fullName) {
      return res.status(400).json({
        success: false,
        message: 'Please provide all required fields'
      });
    }

    // Check if admin already exists
    const existingAdmin = await Admin.findOne({ $or: [{ email }, { username }] });
    if (existingAdmin) {
      return res.status(400).json({
        success: false,
        message: 'Admin with this email or username already exists'
      });
    }

    // Create new admin
    const admin = await Admin.create({
      username,
      email,
      password,
      fullName,
      role: role || 'admin'
    });

    // Remove password from output
    admin.password = undefined;

    res.status(201).json({
      success: true,
      message: 'Admin created successfully',
      data: admin
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: 'Failed to create admin',
      error: error.message
    });
  }
};

/**
 * @desc    Refresh access token
 * @route   POST /api/admin/auth/refresh
 * @access  Public
 */
exports.refreshToken = async (req, res) => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      return res.status(400).json({
        success: false,
        message: 'Refresh token is required'
      });
    }

    // Verify refresh token
    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET || 'your-refresh-secret-key');

    // Find admin with this refresh token
    const admin = await Admin.findById(decoded.id).select('+refreshToken');
    
    if (!admin || admin.refreshToken !== refreshToken) {
      return res.status(401).json({
        success: false,
        message: 'Invalid refresh token'
      });
    }

    // Check if admin is active
    if (!admin.isActive) {
      return res.status(401).json({
        success: false,
        message: 'Your account has been deactivated.'
      });
    }

    // Generate new access token
    const newToken = admin.generateAuthToken();

    res.status(200).json({
      success: true,
      data: {
        token: newToken
      }
    });
  } catch (error) {
    res.status(401).json({
      success: false,
      message: 'Invalid or expired refresh token',
      error: error.message
    });
  }
};

/**
 * @desc    Admin logout
 * @route   POST /api/admin/auth/logout
 * @access  Private
 */
exports.logout = async (req, res) => {
  try {
    // Clear refresh token from database
    req.admin.refreshToken = undefined;
    await req.admin.save({ validateBeforeSave: false });

    res.status(200).json({
      success: true,
      message: 'Logged out successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Logout failed',
      error: error.message
    });
  }
};

/**
 * @desc    Get current admin profile
 * @route   GET /api/admin/auth/me
 * @access  Private
 */
exports.getMe = async (req, res) => {
  try {
    const admin = await Admin.findById(req.admin.id);
    
    res.status(200).json({
      success: true,
      data: admin
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to get admin profile',
      error: error.message
    });
  }
};

/**
 * @desc    Update admin profile
 * @route   PUT /api/admin/auth/update-profile
 * @access  Private
 */
exports.updateProfile = async (req, res) => {
  try {
    const { fullName, email } = req.body;

    const updatedAdmin = await Admin.findByIdAndUpdate(
      req.admin.id,
      { fullName, email },
      { new: true, runValidators: true }
    );

    res.status(200).json({
      success: true,
      message: 'Profile updated successfully',
      data: updatedAdmin
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: 'Failed to update profile',
      error: error.message
    });
  }
};

/**
 * @desc    Change admin password
 * @route   PUT /api/admin/auth/change-password
 * @access  Private
 */
exports.changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({
        success: false,
        message: 'Please provide current and new password'
      });
    }

    // Get admin with password
    const admin = await Admin.findById(req.admin.id).select('+password');

    // Verify current password
    if (!(await admin.comparePassword(currentPassword))) {
      return res.status(401).json({
        success: false,
        message: 'Current password is incorrect'
      });
    }

    // Update password
    admin.password = newPassword;
    admin.passwordChangedAt = new Date();
    await admin.save();

    // Generate new token
    const token = admin.generateAuthToken();

    res.status(200).json({
      success: true,
      message: 'Password changed successfully',
      data: { token }
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: 'Failed to change password',
      error: error.message
    });
  }
};

/**
 * @desc    Forgot password
 * @route   POST /api/admin/auth/forgot-password
 * @access  Public
 */
exports.forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({
        success: false,
        message: 'Please provide an email address'
      });
    }

    // Find admin by email
    const admin = await Admin.findOne({ email });

    if (!admin) {
      // Don't reveal if email exists for security
      return res.status(200).json({
        success: true,
        message: 'If an account exists with this email, a password reset link will be sent.'
      });
    }

    // Generate reset token
    const resetToken = admin.generatePasswordResetToken();
    await admin.save({ validateBeforeSave: false });

    // Create reset URL
    const resetUrl = `${process.env.FRONTEND_URL || 'http://localhost:3000'}/admin/reset-password?token=${resetToken}`;

    // Log for development (in production, send email)
    console.log('Password Reset URL:', resetUrl);
    console.log('Reset Token:', resetToken);

    res.status(200).json({
      success: true,
      message: 'Password reset instructions sent to your email',
      // Only include URL in development
      resetUrl: process.env.NODE_ENV === 'development' ? resetUrl : undefined
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to process password reset request',
      error: error.message
    });
  }
};

/**
 * @desc    Reset password
 * @route   POST /api/admin/auth/reset-password
 * @access  Public
 */
exports.resetPassword = async (req, res) => {
  try {
    const { token, password } = req.body;

    if (!token || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide token and new password'
      });
    }

    // Hash token to match stored hash
    const hashedToken = crypto
      .createHash('sha256')
      .update(token)
      .digest('hex');

    // Find admin with valid reset token
    const admin = await Admin.findOne({
      resetPasswordToken: hashedToken,
      resetPasswordExpire: { $gt: Date.now() }
    }).select('+resetPasswordToken +resetPasswordExpire');

    if (!admin) {
      return res.status(400).json({
        success: false,
        message: 'Invalid or expired reset token'
      });
    }

    // Set new password
    admin.password = password;
    admin.resetPasswordToken = undefined;
    admin.resetPasswordExpire = undefined;
    admin.passwordChangedAt = new Date();
    await admin.save();

    res.status(200).json({
      success: true,
      message: 'Password reset successful'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to reset password',
      error: error.message
    });
  }
};

/**
 * @desc    Get all admins
 * @route   GET /api/admin/auth/all
 * @access  Private (super-admin)
 */
exports.getAllAdmins = async (req, res) => {
  try {
    const admins = await Admin.find().sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: admins.length,
      data: admins
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to get admins',
      error: error.message
    });
  }
};

/**
 * @desc    Toggle admin active status
 * @route   PUT /api/admin/auth/:id/toggle-status
 * @access  Private (super-admin)
 */
exports.toggleAdminStatus = async (req, res) => {
  try {
    const admin = await Admin.findById(req.params.id);

    if (!admin) {
      return res.status(404).json({
        success: false,
        message: 'Admin not found'
      });
    }

    admin.isActive = !admin.isActive;
    await admin.save();

    res.status(200).json({
      success: true,
      message: `Admin ${admin.isActive ? 'activated' : 'deactivated'} successfully`,
      data: admin
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: 'Failed to update admin status',
      error: error.message
    });
  }
};

/**
 * @desc    Delete admin
 * @route   DELETE /api/admin/auth/:id
 * @access  Private (super-admin)
 */
exports.deleteAdmin = async (req, res) => {
  try {
    const admin = await Admin.findByIdAndDelete(req.params.id);

    if (!admin) {
      return res.status(404).json({
        success: false,
        message: 'Admin not found'
      });
    }

    res.status(200).json({
      success: true,
      message: 'Admin deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to delete admin',
      error: error.message
    });
  }
};
