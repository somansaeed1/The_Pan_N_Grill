const Order = require('../models/Order');
const User = require('../models/User');
const Product = require('../models/Product');
const Category = require('../models/Category');

/**
 * @desc    Admin global search across all collections
 * @route   GET /api/admin/search
 * @access  Private (Admin)
 */
exports.globalSearch = async (req, res) => {
  try {
    const { 
      q, 
      type, 
      page = 1, 
      limit = 20 
    } = req.query;

    if (!q) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a search query (q parameter)'
      });
    }

    const skip = (page - 1) * limit;
    const results = {};

    // Search all or specific type
    const searchTypes = type ? [type] : ['orders', 'users', 'products', 'categories'];

    // Search Orders by order number, customer name, email, phone
    if (searchTypes.includes('orders')) {
      const orderQuery = {
        $or: [
          { orderNumber: { $regex: q, $options: 'i' } },
          { customerName: { $regex: q, $options: 'i' } },
          { customerEmail: { $regex: q, $options: 'i' } },
          { customerPhone: { $regex: q, $options: 'i' } }
        ]
      };

      const orders = await Order.find(orderQuery)
        .populate('items.product', 'name price')
        .populate('user', 'name email')
        .sort({ createdAt: -1 })
        .limit(parseInt(limit))
        .skip(skip);

      const totalOrders = await Order.countDocuments(orderQuery);

      results.orders = {
        data: orders,
        count: orders.length,
        total: totalOrders,
        page: parseInt(page),
        pages: Math.ceil(totalOrders / limit)
      };
    }

    // Search Users by name, email, phone
    if (searchTypes.includes('users')) {
      const userQuery = {
        $or: [
          { name: { $regex: q, $options: 'i' } },
          { email: { $regex: q, $options: 'i' } },
          { phone: { $regex: q, $options: 'i' } }
        ]
      };

      const users = await User.find(userQuery)
        .select('-password')
        .populate('blockedBy', 'name email')
        .sort({ createdAt: -1 })
        .limit(parseInt(limit))
        .skip(skip);

      const totalUsers = await User.countDocuments(userQuery);

      results.users = {
        data: users,
        count: users.length,
        total: totalUsers,
        page: parseInt(page),
        pages: Math.ceil(totalUsers / limit)
      };
    }

    // Search Products by name, description
    if (searchTypes.includes('products')) {
      const productQuery = {
        $or: [
          { name: { $regex: q, $options: 'i' } },
          { description: { $regex: q, $options: 'i' } }
        ],
        isDeleted: { $ne: true }
      };

      const products = await Product.find(productQuery)
        .populate('category', 'name')
        .sort({ createdAt: -1 })
        .limit(parseInt(limit))
        .skip(skip);

      const totalProducts = await Product.countDocuments(productQuery);

      results.products = {
        data: products,
        count: products.length,
        total: totalProducts,
        page: parseInt(page),
        pages: Math.ceil(totalProducts / limit)
      };
    }

    // Search Categories by name, description
    if (searchTypes.includes('categories')) {
      const categoryQuery = {
        $or: [
          { name: { $regex: q, $options: 'i' } },
          { description: { $regex: q, $options: 'i' } }
        ]
      };

      const categories = await Category.find(categoryQuery)
        .sort({ createdAt: -1 })
        .limit(parseInt(limit))
        .skip(skip);

      const totalCategories = await Category.countDocuments(categoryQuery);

      results.categories = {
        data: categories,
        count: categories.length,
        total: totalCategories,
        page: parseInt(page),
        pages: Math.ceil(totalCategories / limit)
      };
    }

    res.status(200).json({
      success: true,
      query: q,
      searchType: type || 'all',
      results
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Search failed',
      error: error.message
    });
  }
};

/**
 * @desc    Search orders by ID or order number
 * @route   GET /api/admin/search/orders
 * @access  Private (Admin)
 */
exports.searchOrders = async (req, res) => {
  try {
    const { 
      q,
      status,
      orderType,
      startDate,
      endDate,
      page = 1, 
      limit = 20 
    } = req.query;

    const query = {};

    // Search by order number, ID, customer info
    if (q) {
      // Check if query is a valid MongoDB ObjectId
      const isObjectId = /^[0-9a-fA-F]{24}$/.test(q);
      
      if (isObjectId) {
        query._id = q;
      } else {
        query.$or = [
          { orderNumber: { $regex: q, $options: 'i' } },
          { customerName: { $regex: q, $options: 'i' } },
          { customerEmail: { $regex: q, $options: 'i' } },
          { customerPhone: { $regex: q, $options: 'i' } }
        ];
      }
    }

    // Status filter
    if (status) {
      query.status = status;
    }

    // Order type filter
    if (orderType) {
      query.orderType = orderType;
    }

    // Date range filter
    if (startDate || endDate) {
      query.createdAt = {};
      if (startDate) {
        query.createdAt.$gte = new Date(startDate);
      }
      if (endDate) {
        query.createdAt.$lte = new Date(endDate);
      }
    }

    const skip = (page - 1) * limit;

    const orders = await Order.find(query)
      .populate('items.product', 'name price image')
      .populate('user', 'name email phone')
      .populate('statusHistory.changedBy', 'name email')
      .sort({ createdAt: -1 })
      .limit(parseInt(limit))
      .skip(skip);

    const total = await Order.countDocuments(query);

    res.status(200).json({
      success: true,
      count: orders.length,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit),
      data: orders
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Order search failed',
      error: error.message
    });
  }
};

/**
 * @desc    Search users by email, name, or phone
 * @route   GET /api/admin/search/users
 * @access  Private (Admin)
 */
exports.searchUsers = async (req, res) => {
  try {
    const { 
      q,
      isBlocked,
      page = 1, 
      limit = 20 
    } = req.query;

    const query = {};

    // Search by email, name, phone
    if (q) {
      // Check if it's an email pattern
      const isEmail = /^\S+@\S+\.\S+$/.test(q);
      
      if (isEmail) {
        query.email = { $regex: q, $options: 'i' };
      } else {
        query.$or = [
          { name: { $regex: q, $options: 'i' } },
          { email: { $regex: q, $options: 'i' } },
          { phone: { $regex: q, $options: 'i' } }
        ];
      }
    }

    // Block status filter
    if (isBlocked !== undefined) {
      query.isBlocked = isBlocked === 'true';
    }

    const skip = (page - 1) * limit;

    const users = await User.find(query)
      .select('-password')
      .populate('blockedBy', 'name email role')
      .sort({ createdAt: -1 })
      .limit(parseInt(limit))
      .skip(skip);

    const total = await User.countDocuments(query);

    res.status(200).json({
      success: true,
      count: users.length,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit),
      data: users
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'User search failed',
      error: error.message
    });
  }
};

/**
 * @desc    Search products by name or category
 * @route   GET /api/admin/search/products
 * @access  Private (Admin)
 */
exports.searchProducts = async (req, res) => {
  try {
    const { 
      q,
      category,
      isAvailable,
      minPrice,
      maxPrice,
      includeDeleted = false,
      page = 1, 
      limit = 20 
    } = req.query;

    const query = {};

    // Search by name or description
    if (q) {
      query.$or = [
        { name: { $regex: q, $options: 'i' } },
        { description: { $regex: q, $options: 'i' } }
      ];
    }

    // Category filter
    if (category) {
      // Check if category is ObjectId or name
      const isObjectId = /^[0-9a-fA-F]{24}$/.test(category);
      
      if (isObjectId) {
        query.category = category;
      } else {
        // Find category by name
        const categoryDoc = await Category.findOne({ 
          name: { $regex: category, $options: 'i' } 
        });
        if (categoryDoc) {
          query.category = categoryDoc._id;
        }
      }
    }

    // Availability filter
    if (isAvailable !== undefined) {
      query.isAvailable = isAvailable === 'true';
    }

    // Price range filter
    if (minPrice || maxPrice) {
      query.price = {};
      if (minPrice) {
        query.price.$gte = parseFloat(minPrice);
      }
      if (maxPrice) {
        query.price.$lte = parseFloat(maxPrice);
      }
    }

    // Exclude deleted products unless explicitly requested
    if (includeDeleted !== 'true') {
      query.isDeleted = { $ne: true };
    }

    const skip = (page - 1) * limit;

    const products = await Product.find(query)
      .populate('category', 'name')
      .sort({ createdAt: -1 })
      .limit(parseInt(limit))
      .skip(skip);

    const total = await Product.countDocuments(query);

    res.status(200).json({
      success: true,
      count: products.length,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit),
      data: products
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Product search failed',
      error: error.message
    });
  }
};

/**
 * @desc    Quick search - returns minimal data for autocomplete
 * @route   GET /api/admin/search/quick
 * @access  Private (Admin)
 */
exports.quickSearch = async (req, res) => {
  try {
    const { q, type } = req.query;

    if (!q || q.length < 2) {
      return res.status(400).json({
        success: false,
        message: 'Query must be at least 2 characters'
      });
    }

    const results = {};
    const limit = 5; // Quick search returns fewer results

    // Search specific type or all
    const searchTypes = type ? [type] : ['orders', 'users', 'products'];

    if (searchTypes.includes('orders')) {
      results.orders = await Order.find({
        $or: [
          { orderNumber: { $regex: q, $options: 'i' } },
          { customerName: { $regex: q, $options: 'i' } },
          { customerEmail: { $regex: q, $options: 'i' } }
        ]
      })
        .select('orderNumber customerName customerEmail status totalAmount createdAt')
        .sort({ createdAt: -1 })
        .limit(limit);
    }

    if (searchTypes.includes('users')) {
      results.users = await User.find({
        $or: [
          { name: { $regex: q, $options: 'i' } },
          { email: { $regex: q, $options: 'i' } }
        ]
      })
        .select('name email phone isBlocked')
        .sort({ createdAt: -1 })
        .limit(limit);
    }

    if (searchTypes.includes('products')) {
      results.products = await Product.find({
        name: { $regex: q, $options: 'i' },
        isDeleted: { $ne: true }
      })
        .select('name price image isAvailable')
        .populate('category', 'name')
        .sort({ createdAt: -1 })
        .limit(limit);
    }

    res.status(200).json({
      success: true,
      query: q,
      results
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Quick search failed',
      error: error.message
    });
  }
};
