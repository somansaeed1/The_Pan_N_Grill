### The directory named pan-n-grill-nextjs\_\_\_admin-panel has complete project both front-end and backend. To run the project open 2 terminals. In the 1st terminal perform these steps:

1. **Step 1
   npm install**

2. **Step 2
   npm run build**

3. **Step 3**
3. 
**&nbsp;  npm run dev**



#### Open 2nd terminal and run the following command to connect the backend.

* npm run server: dev



