require('dotenv').config();
const mongoose = require('mongoose');
const Category = require('./models/Category');
const Product = require('./models/Product');

const seedData = async () => {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('✅ Connected to MongoDB');

    // Clear existing data
    await Category.deleteMany({});
    await Product.deleteMany({});
    console.log('🗑️  Cleared existing data');

    // Category to ID mapping
    const categoryMap = {};

    // Menu Data from menuData.ts
    const menuData = {
      'special-pizza': {
        name: 'Special Pizza',
        description: 'Premium pizzas with special toppings and traditional flavors',
        displayOrder: 1,
        items: [
          { name: 'Family Pizza', price: 2000, description: 'Extra large pizza perfect for sharing with the whole family, loaded with premium toppings and our signature blend of cheeses.', spicyLevel: 'none', preparationTime: 25 },
          { name: 'X-Large Pizza', price: 1750, description: 'Generously sized pizza with a crispy golden crust, topped with fresh ingredients and melted mozzarella cheese.', spicyLevel: 'none', preparationTime: 25 },
          { name: 'Royal Kabab Crust', price: 1100, description: 'Premium pizza with a unique kabab-stuffed crust, featuring tender spiced meat wrapped in our signature dough.', spicyLevel: 'medium', preparationTime: 30 },
          { name: 'Pan N Grill Special', price: 1100, description: 'Our signature pizza featuring a perfect blend of grilled chicken, fresh vegetables, and aromatic spices on a crispy base.', spicyLevel: 'mild', preparationTime: 25 },
          { name: 'Kabab Crust Pizza', price: 1100, description: 'Innovative pizza with kabab meat baked into the crust edges, creating a delicious surprise with every bite.', spicyLevel: 'medium', preparationTime: 30 },
          { name: 'Malaie Boti Pizza', price: 1100, description: 'Rich and creamy pizza topped with tender malai boti pieces, fresh cream, and aromatic herbs for an indulgent experience.', spicyLevel: 'mild', preparationTime: 25 },
          { name: 'Mughlai Pizza', price: 1100, description: 'Royal-inspired pizza with rich Mughlai flavors, featuring tender meat, nuts, and aromatic spices on a golden crust.', spicyLevel: 'mild', preparationTime: 25 },
          { name: 'Chicken Tandoori Pizza', price: 1100, description: 'Authentic tandoori chicken pieces on a crispy pizza base, marinated with traditional spices and yogurt.', spicyLevel: 'hot', preparationTime: 25 },
          { name: 'Afghani Pizza', price: 1100, description: 'Bold and flavorful pizza featuring Afghani-style marinated meat with a perfect blend of spices and fresh herbs.', spicyLevel: 'mild', preparationTime: 25 },
          { name: 'Kabab Stuff Pizza', price: 1100, description: 'Stuffed pizza with generous portions of spiced kabab meat inside the crust, topped with cheese and fresh vegetables.', spicyLevel: 'medium', preparationTime: 30 }
        ]
      },
      'regular-pizza': {
        name: 'Regular Pizza',
        description: 'Classic pizza varieties with fresh toppings',
        displayOrder: 2,
        items: [
          { name: 'Tikka Pizza', price: 1000, description: 'Classic tikka pizza with tender marinated chicken pieces, onions, and bell peppers on a crispy base.', spicyLevel: 'mild', preparationTime: 20 },
          { name: 'Fajita Pizza', price: 1000, description: 'Mexican-inspired pizza with seasoned chicken, colorful bell peppers, onions, and melted cheese.', spicyLevel: 'mild', preparationTime: 20 },
          { name: 'Supreme Pizza', price: 1000, description: 'Loaded supreme pizza with pepperoni, sausage, mushrooms, bell peppers, and onions for the ultimate flavor experience.', spicyLevel: 'none', preparationTime: 20 },
          { name: 'Bar B-Q Pizza', price: 1000, description: 'Smoky barbeque pizza with grilled chicken, tangy BBQ sauce, red onions, and cilantro on a crispy crust.', spicyLevel: 'mild', preparationTime: 20 },
          { name: 'Achari Pizza', price: 1000, description: 'Tangy and spicy achari pizza featuring pickled chicken with traditional Pakistani pickle spices and fresh herbs.', spicyLevel: 'hot', preparationTime: 20 },
          { name: 'Italian Pizza', price: 1000, description: 'Authentic Italian-style pizza with fresh basil, mozzarella, tomato sauce, and premium Italian seasonings.', spicyLevel: 'none', preparationTime: 20, isVegetarian: true },
          { name: 'Hot N Spicy Pizza', price: 1000, description: 'Fiery hot pizza with spicy chicken, jalapeños, and our signature hot sauce for those who love bold flavors.', spicyLevel: 'extra-hot', preparationTime: 20 },
          { name: 'Multi Flavour Pizza', price: 1100, description: 'Four different flavors in one pizza - tikka, fajita, BBQ, and supreme - perfect for sharing and trying multiple tastes.', spicyLevel: 'mild', preparationTime: 25 }
        ]
      },
      'special-shawarmas': {
        name: 'Special Shawarmas',
        description: 'Fresh shawarmas with premium ingredients',
        displayOrder: 3,
        items: [
          { name: 'Chicken Shawarma', price: 200, description: 'Tender marinated chicken wrapped in soft pita bread with fresh vegetables, garlic sauce, and pickles.', spicyLevel: 'mild', preparationTime: 10 },
          { name: 'Achari Shawarma', price: 220, description: 'Spicy achari-marinated chicken with tangy pickle flavors, wrapped in warm pita with fresh salad.', spicyLevel: 'hot', preparationTime: 10 },
          { name: 'Malai Boti Shawarma', price: 250, description: 'Creamy malai boti pieces with rich cream sauce, wrapped in soft bread with fresh vegetables.', spicyLevel: 'mild', preparationTime: 12 },
          { name: 'Zinger Shawarma', price: 300, description: 'Crispy zinger chicken fillet with spicy mayo, lettuce, and tomatoes in a soft pita wrap.', spicyLevel: 'medium', preparationTime: 12 },
          { name: 'Special Shawarma', price: 250, description: 'Our signature shawarma with premium chicken, special sauce, and a perfect blend of fresh ingredients.', spicyLevel: 'mild', preparationTime: 10 },
          { name: 'Grilled Shawarma', price: 300, description: 'Perfectly grilled chicken with smoky flavors, fresh vegetables, and garlic sauce in warm pita bread.', spicyLevel: 'mild', preparationTime: 12 },
          { name: 'Chicken Cheese Shawarma', price: 250, description: 'Tender chicken with melted cheese, fresh vegetables, and garlic sauce wrapped in soft pita.', spicyLevel: 'mild', preparationTime: 10 },
          { name: 'Zinger Cheese Shawarma', price: 350, description: 'Crispy zinger chicken with extra cheese, spicy mayo, and fresh vegetables in a warm pita wrap.', spicyLevel: 'medium', preparationTime: 12 },
          { name: 'Platter Shawarma', price: 350, description: 'Generous platter with shawarma meat, fresh salad, garlic sauce, and warm pita bread for sharing.', spicyLevel: 'mild', preparationTime: 15 }
        ]
      },
      'burgers': {
        name: 'Burgers',
        description: 'Juicy burgers with fresh ingredients',
        displayOrder: 4,
        items: [
          { name: 'Modern Burger', price: 450, description: 'Contemporary burger with premium beef patty, fresh lettuce, tomatoes, onions, and our signature sauce.', spicyLevel: 'mild', preparationTime: 15 },
          { name: 'Zinger Burger', price: 350, description: 'Crispy zinger chicken fillet with spicy mayo, fresh lettuce, and tomatoes in a soft bun.', spicyLevel: 'medium', preparationTime: 12 },
          { name: 'Chicken Patty Burger', price: 300, description: 'Juicy chicken patty with fresh vegetables, cheese, and tangy sauce in a toasted bun.', spicyLevel: 'mild', preparationTime: 10 },
          { name: 'Chapli Burger', price: 250, description: 'Authentic chapli kebab patty with traditional spices, onions, and fresh herbs in a soft bun.', spicyLevel: 'hot', preparationTime: 12 },
          { name: 'Special Kabab Burger', price: 400, description: 'Premium kabab patty with aromatic spices, fresh vegetables, and our special sauce.', spicyLevel: 'medium', preparationTime: 15 },
          { name: 'Grill Burger', price: 320, description: 'Perfectly grilled chicken patty with smoky flavors, cheese, and fresh vegetables.', spicyLevel: 'mild', preparationTime: 12 },
          { name: 'Tower Burger', price: 450, description: 'Tall burger with multiple layers of meat, cheese, and vegetables for the ultimate indulgence.', spicyLevel: 'mild', preparationTime: 15 },
          { name: 'Double Decker Cheese Burger', price: 500, description: 'Double-layered burger with two beef patties, extra cheese, and fresh vegetables for maximum satisfaction.', spicyLevel: 'mild', preparationTime: 18 }
        ]
      },
      'pasta': {
        name: 'Pasta',
        description: 'Delicious pasta dishes with various flavors',
        displayOrder: 5,
        items: [
          { name: 'Malai Botti Pasta', price: 800, description: 'Creamy pasta with tender malai boti pieces, rich cream sauce, and aromatic herbs for an indulgent experience.', spicyLevel: 'mild', preparationTime: 20, isVegetarian: false },
          { name: 'Crunchy Pasta', price: 750, description: 'Al dente pasta with crispy vegetables, nuts, and a perfect blend of textures and flavors.', spicyLevel: 'none', preparationTime: 18, isVegetarian: true },
          { name: 'Creamy & Cheesy Pasta', price: 700, description: 'Rich and creamy pasta loaded with melted cheese, fresh herbs, and premium ingredients.', spicyLevel: 'none', preparationTime: 18, isVegetarian: true },
          { name: 'Tandoori Pasta', price: 700, description: 'Authentic tandoori-flavored pasta with marinated chicken, yogurt, and traditional spices.', spicyLevel: 'hot', preparationTime: 20 },
          { name: 'Hot & Spicy Pasta', price: 650, description: 'Fiery hot pasta with spicy chicken, jalapeños, and our signature hot sauce for bold flavor lovers.', spicyLevel: 'extra-hot', preparationTime: 18 }
        ]
      },
      'fried-items': {
        name: 'Fried Items',
        description: 'Crispy fried chicken and snacks',
        displayOrder: 6,
        items: [
          { name: 'Bake Oven Broast', price: 1600, description: 'Whole chicken baked to perfection in our special oven with aromatic spices and herbs.', spicyLevel: 'mild', preparationTime: 45 },
          { name: 'Full Broast', price: 1600, description: 'Crispy fried whole chicken with our signature spice blend.', spicyLevel: 'medium', preparationTime: 40 },
          { name: 'Half Broast', price: 800, description: 'Crispy fried half chicken with our signature spice blend.', spicyLevel: 'medium', preparationTime: 30 },
          { name: 'Quarter Broast', price: 400, description: 'Crispy fried quarter chicken with our signature spice blend.', spicyLevel: 'medium', preparationTime: 20 },
          { name: 'Hot Wings (10 Pcs)', price: 700, description: 'Spicy chicken wings with our signature hot sauce, perfectly crispy and flavorful.', spicyLevel: 'hot', preparationTime: 15 },
          { name: 'Hot Wings (5 Pcs)', price: 350, description: 'Spicy chicken wings with our signature hot sauce, perfectly crispy and flavorful.', spicyLevel: 'hot', preparationTime: 12 },
          { name: 'Nuggets (10 Pcs)', price: 600, description: 'Crispy chicken nuggets with tender meat inside, perfect for snacking or sharing.', spicyLevel: 'mild', preparationTime: 10 },
          { name: 'Nuggets (5 Pcs)', price: 300, description: 'Crispy chicken nuggets with tender meat inside, perfect for snacking or sharing.', spicyLevel: 'mild', preparationTime: 8 },
          { name: 'Chest Piece', price: 350, description: 'Juicy chicken breast piece with crispy coating and aromatic spices.', spicyLevel: 'mild', preparationTime: 15 },
          { name: 'Leg Piece', price: 350, description: 'Tender chicken leg piece with crispy skin and flavorful marinade.', spicyLevel: 'mild', preparationTime: 15 },
          { name: 'Chicken Samosa', price: 80, description: 'Crispy triangular pastry filled with spiced chicken, onions, and aromatic herbs.', spicyLevel: 'medium', preparationTime: 5 },
          { name: 'Chicken Pakora (1 kg)', price: 1000, description: 'Crispy chicken pakoras with gram flour coating, perfect for sharing with family and friends.', spicyLevel: 'hot', preparationTime: 20 }
        ]
      },
      'beverages': {
        name: 'Beverages',
        description: 'Refreshing cold drinks',
        displayOrder: 7,
        items: [
          { name: 'Coke (350ml)', price: 100, description: 'Classic Coca-Cola with refreshing taste and fizzy bubbles.', spicyLevel: 'none', preparationTime: 1 },
          { name: 'Coke (1.5 Ltr)', price: 220, description: 'Classic Coca-Cola with refreshing taste and fizzy bubbles.', spicyLevel: 'none', preparationTime: 1 },
          { name: 'Sprite (350ml)', price: 100, description: 'Refreshing lemon-lime soda with crisp, clean taste and fizzy bubbles.', spicyLevel: 'none', preparationTime: 1 },
          { name: 'Sprite (1.5 Ltr)', price: 220, description: 'Refreshing lemon-lime soda with crisp, clean taste and fizzy bubbles.', spicyLevel: 'none', preparationTime: 1 },
          { name: 'Mineral Water (350ml)', price: 70, description: 'Pure mineral water with natural minerals for hydration and refreshment.', spicyLevel: 'none', preparationTime: 1 },
          { name: 'Mineral Water (1.5 Ltr)', price: 100, description: 'Pure mineral water with natural minerals for hydration and refreshment.', spicyLevel: 'none', preparationTime: 1 }
        ]
      },
      'deals': {
        name: 'Special Deals',
        description: 'Value combo deals for families',
        displayOrder: 8,
        items: [
          { name: '2 X-Large Pizza + 1.5 Ltr Coke', price: 3200, description: 'Perfect family deal with two extra-large pizzas and a refreshing 1.5L Coke for sharing.', spicyLevel: 'none', preparationTime: 35 },
          { name: '2 Large Pizza + 1.5 Ltr Coke', price: 2700, description: 'Great value deal with two large pizzas and a 1.5L Coke for a satisfying meal.', spicyLevel: 'none', preparationTime: 30 },
          { name: '2 Medium Pizza + 1.5 Ltr Coke', price: 1800, description: 'Perfect for couples with two medium pizzas and a refreshing 1.5L Coke.', spicyLevel: 'none', preparationTime: 25 },
          { name: '5 Zinger Burger + 1.5 Ltr Coke', price: 1600, description: 'Burger lovers deal with five crispy zinger burgers and a 1.5L Coke for sharing.', spicyLevel: 'medium', preparationTime: 20 },
          { name: 'Pasta + Burger + Fries + Coke', price: 1100, description: 'Complete meal deal with creamy pasta, zinger burger, regular fries, and 1L Coke.', spicyLevel: 'mild', preparationTime: 25 }
        ]
      }
    };

    // Create categories and products
    for (const [categoryId, categoryData] of Object.entries(menuData)) {
      // Create category
      const category = await Category.create({
        name: categoryData.name,
        description: categoryData.description,
        isActive: true,
        displayOrder: categoryData.displayOrder
      });

      categoryMap[categoryId] = category._id;
      console.log(`✅ Created category: ${category.name}`);

      // Create products for this category
      for (const item of categoryData.items) {
        await Product.create({
          name: item.name,
          description: item.description,
          price: item.price,
          category: category._id,
          isAvailable: true,
          isVegetarian: item.isVegetarian || false,
          spicyLevel: item.spicyLevel || 'none',
          preparationTime: item.preparationTime || 15
        });
      }

      console.log(`  ↳ Added ${categoryData.items.length} products`);
    }

    // Summary
    const totalCategories = await Category.countDocuments();
    const totalProducts = await Product.countDocuments();

    console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('✅ Database seeded successfully!');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log(`📦 Total Categories: ${totalCategories}`);
    console.log(`🍔 Total Products: ${totalProducts}`);
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

  } catch (error) {
    console.error('❌ Error seeding database:', error.message);
  } finally {
    await mongoose.connection.close();
    console.log('🔌 Database connection closed');
  }
};

seedData();
