const mongoose = require('mongoose');

const adminLogSchema = new mongoose.Schema({
  admin: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Admin',
    required: true
  },
  action: {
    type: String,
    required: [true, 'Action is required'],
    trim: true
  },
  method: {
    type: String,
    enum: ['POST', 'PUT', 'PATCH', 'DELETE', 'GET'],
    required: true
  },
  endpoint: {
    type: String,
    required: true
  },
  resourceType: {
    type: String,
    enum: ['Product', 'Category', 'Order', 'User', 'Admin', 'Settings', 'Media', 'Other'],
    required: true
  },
  resourceId: {
    type: String // Can be ObjectId or other identifier
  },
  changes: {
    type: mongoose.Schema.Types.Mixed // Stores before/after data
  },
  statusCode: {
    type: Number,
    required: true
  },
  ipAddress: {
    type: String
  },
  userAgent: {
    type: String
  },
  success: {
    type: Boolean,
    default: true
  },
  errorMessage: {
    type: String
  }
}, {
  timestamps: true
});

// Indexes for efficient querying
adminLogSchema.index({ admin: 1, createdAt: -1 });
adminLogSchema.index({ resourceType: 1, createdAt: -1 });
adminLogSchema.index({ action: 1 });
adminLogSchema.index({ createdAt: -1 });

// Static method to create log entry
adminLogSchema.statics.logAction = async function(logData) {
  try {
    const log = await this.create(logData);
    return log;
  } catch (error) {
    console.error('Failed to create activity log:', error);
    // Don't throw error to prevent breaking the main operation
    return null;
  }
};

// Static method to get logs with filters
adminLogSchema.statics.getFilteredLogs = async function(filters, options = {}) {
  const {
    admin,
    resourceType,
    action,
    startDate,
    endDate,
    page = 1,
    limit = 50
  } = { ...filters, ...options };

  const query = {};

  if (admin) query.admin = admin;
  if (resourceType) query.resourceType = resourceType;
  if (action) query.action = { $regex: action, $options: 'i' };

  // Date range filter
  if (startDate || endDate) {
    query.createdAt = {};
    if (startDate) query.createdAt.$gte = new Date(startDate);
    if (endDate) query.createdAt.$lte = new Date(endDate);
  }

  const skip = (page - 1) * limit;

  const logs = await this.find(query)
    .populate('admin', 'name email role')
    .sort({ createdAt: -1 })
    .limit(parseInt(limit))
    .skip(skip);

  const total = await this.countDocuments(query);

  return {
    logs,
    pagination: {
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit),
      limit: parseInt(limit)
    }
  };
};

module.exports = mongoose.model('AdminLog', adminLogSchema);
