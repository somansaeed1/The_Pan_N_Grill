const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Name is required'],
    trim: true,
    minlength: [2, 'Name must be at least 2 characters']
  },
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
    trim: true,
    lowercase: true,
    match: [/^\S+@\S+\.\S+$/, 'Please provide a valid email address']
  },
  phone: {
    type: String,
    required: [true, 'Phone number is required'],
    trim: true
  },
  password: {
    type: String,
    required: [true, 'Password is required'],
    minlength: [6, 'Password must be at least 6 characters'],
    select: false // Don't return password by default
  },
  addresses: [{
    street: String,
    city: String,
    postalCode: String,
    coordinates: {
      lat: Number,
      lng: Number
    },
    isDefault: {
      type: Boolean,
      default: false
    }
  }],
  isBlocked: {
    type: Boolean,
    default: false
  },
  blockedAt: {
    type: Date
  },
  blockedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Admin'
  },
  blockReason: {
    type: String,
    maxlength: [200, 'Block reason must not exceed 200 characters']
  },
  lastLogin: {
    type: Date
  },
  totalOrders: {
    type: Number,
    default: 0
  },
  totalSpent: {
    type: Number,
    default: 0
  }
}, {
  timestamps: true
});

// Hash password before saving
userSchema.pre('save', async function(next) {
  // Only hash if password is modified
  if (!this.isModified('password')) {
    return next();
  }

  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error);
  }
});

// Method to compare password
userSchema.methods.comparePassword = async function(candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

// Method to block user
userSchema.methods.block = function(adminId, reason = '') {
  this.isBlocked = true;
  this.blockedAt = new Date();
  this.blockedBy = adminId;
  this.blockReason = reason;
  return this;
};

// Method to unblock user
userSchema.methods.unblock = function() {
  this.isBlocked = false;
  this.blockedAt = undefined;
  this.blockedBy = undefined;
  this.blockReason = undefined;
  return this;
};

// Method to check if user can place order
userSchema.methods.canPlaceOrder = function() {
  return !this.isBlocked;
};

// Index for faster lookups
userSchema.index({ email: 1 });
userSchema.index({ isBlocked: 1 });

module.exports = mongoose.model('User', userSchema);
