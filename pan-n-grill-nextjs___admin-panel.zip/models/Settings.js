const mongoose = require('mongoose');

const settingsSchema = new mongoose.Schema({
  // Restaurant Information
  restaurantName: {
    type: String,
    required: [true, 'Restaurant name is required'],
    trim: true
  },
  restaurantPhone: {
    type: String,
    required: [true, 'Restaurant phone is required'],
    trim: true
  },
  restaurantEmail: {
    type: String,
    required: [true, 'Restaurant email is required'],
    trim: true,
    lowercase: true,
    match: [/^\S+@\S+\.\S+$/, 'Please provide a valid email address']
  },
  address: {
    street: {
      type: String,
      required: [true, 'Street address is required']
    },
    city: {
      type: String,
      required: [true, 'City is required']
    },
    state: {
      type: String
    },
    postalCode: {
      type: String,
      required: [true, 'Postal code is required']
    },
    country: {
      type: String,
      default: 'Pakistan'
    }
  },
  
  // Operating Hours
  operatingHours: {
    monday: { open: String, close: String, isClosed: { type: Boolean, default: false } },
    tuesday: { open: String, close: String, isClosed: { type: Boolean, default: false } },
    wednesday: { open: String, close: String, isClosed: { type: Boolean, default: false } },
    thursday: { open: String, close: String, isClosed: { type: Boolean, default: false } },
    friday: { open: String, close: String, isClosed: { type: Boolean, default: false } },
    saturday: { open: String, close: String, isClosed: { type: Boolean, default: false } },
    sunday: { open: String, close: String, isClosed: { type: Boolean, default: false } }
  },

  // Business Status
  isOpen: {
    type: Boolean,
    default: true
  },
  closureReason: {
    type: String,
    maxlength: [200, 'Closure reason must not exceed 200 characters']
  },
  closedUntil: {
    type: Date
  },

  // Tax Settings
  taxRate: {
    type: Number,
    required: [true, 'Tax rate is required'],
    min: [0, 'Tax rate must be at least 0'],
    max: [100, 'Tax rate must not exceed 100'],
    default: 0
  },
  taxEnabled: {
    type: Boolean,
    default: true
  },

  // Delivery Settings
  deliveryFee: {
    type: Number,
    required: [true, 'Delivery fee is required'],
    min: [0, 'Delivery fee must be at least 0'],
    default: 0
  },
  freeDeliveryThreshold: {
    type: Number,
    min: [0, 'Free delivery threshold must be at least 0'],
    default: 0
  },
  minimumOrderAmount: {
    type: Number,
    required: [true, 'Minimum order amount is required'],
    min: [0, 'Minimum order amount must be at least 0'],
    default: 0
  },
  deliveryEnabled: {
    type: Boolean,
    default: true
  },
  deliveryRadius: {
    type: Number,
    min: [0, 'Delivery radius must be positive'],
    default: 10 // in kilometers
  },

  // Payment Settings
  acceptedPaymentMethods: {
    cash: { type: Boolean, default: true },
    card: { type: Boolean, default: true },
    online: { type: Boolean, default: true }
  },

  // Notification Settings
  notifications: {
    email: {
      enabled: { type: Boolean, default: true },
      recipients: [String]
    },
    sms: {
      enabled: { type: Boolean, default: false },
      recipients: [String]
    }
  },

  // Social Media
  socialMedia: {
    facebook: String,
    instagram: String,
    twitter: String,
    youtube: String
  },

  // Last Update Info
  lastUpdatedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Admin'
  }
}, {
  timestamps: true
});

// Ensure only one settings document exists (singleton pattern)
settingsSchema.statics.getSettings = async function() {
  let settings = await this.findOne();
  
  // Create default settings if none exist
  if (!settings) {
    settings = await this.create({
      restaurantName: 'Pan N Grill',
      restaurantPhone: '+92 300 1234567',
      restaurantEmail: 'info@panngrill.com',
      address: {
        street: '123 Main Street',
        city: 'Lahore',
        state: 'Punjab',
        postalCode: '54000',
        country: 'Pakistan'
      },
      taxRate: 0,
      deliveryFee: 50,
      minimumOrderAmount: 500,
      freeDeliveryThreshold: 2000
    });
  }
  
  return settings;
};

// Method to toggle restaurant open/close
settingsSchema.methods.toggleOpenStatus = function(isOpen, reason = '', closedUntil = null) {
  this.isOpen = isOpen;
  this.closureReason = isOpen ? undefined : reason;
  this.closedUntil = isOpen ? undefined : closedUntil;
  return this;
};

module.exports = mongoose.model('Settings', settingsSchema);
