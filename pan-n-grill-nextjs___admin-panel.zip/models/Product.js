const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Product name is required'],
    trim: true,
    minlength: [2, 'Product name must be at least 2 characters long'],
    maxlength: [100, 'Product name must not exceed 100 characters']
  },
  description: {
    type: String,
    trim: true,
    maxlength: [1000, 'Description must not exceed 1000 characters']
  },
  price: {
    type: Number,
    required: [true, 'Product price is required'],
    min: [0, 'Price must be a positive number']
  },
  category: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Category',
    required: [true, 'Product category is required']
  },
  image: {
    type: String,
    trim: true
  },
  isAvailable: {
    type: Boolean,
    default: true
  },
  isVegetarian: {
    type: Boolean,
    default: false
  },
  spicyLevel: {
    type: String,
    enum: ['none', 'mild', 'medium', 'hot', 'extra-hot'],
    default: 'none'
  },
  preparationTime: {
    type: Number,
    default: 15,
    min: [0, 'Preparation time must be positive']
  },
  calories: {
    type: Number,
    min: [0, 'Calories must be positive']
  },
  isDeleted: {
    type: Boolean,
    default: false,
    select: false // Hide from default queries
  },
  deletedAt: {
    type: Date,
    select: false
  }
}, {
  timestamps: true
});

// Index for better query performance
productSchema.index({ category: 1, isAvailable: 1 });
productSchema.index({ name: 'text', description: 'text' });

// Query middleware to exclude soft-deleted products by default
productSchema.pre(/^find/, function(next) {
  // 'this' points to the current query
  if (!this.getOptions().includeDeleted) {
    this.find({ isDeleted: { $ne: true } });
  }
  next();
});

// Method to soft delete a product
productSchema.methods.softDelete = function() {
  this.isDeleted = true;
  this.deletedAt = new Date();
  this.isAvailable = false;
  return this.save();
};

// Method to restore a soft-deleted product
productSchema.methods.restore = function() {
  this.isDeleted = false;
  this.deletedAt = undefined;
  return this.save();
};

module.exports = mongoose.model('Product', productSchema);
