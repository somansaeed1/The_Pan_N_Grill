require('dotenv').config();
const mongoose = require('mongoose');
const Admin = require('./models/Admin');

const createSuperAdmin = async () => {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('✅ Connected to MongoDB');

    // Check if super admin already exists
    const existingSuperAdmin = await Admin.findOne({ role: 'super-admin' });
    if (existingSuperAdmin) {
      console.log('⚠️  Super admin already exists!');
      console.log('Username:', existingSuperAdmin.username);
      console.log('Email:', existingSuperAdmin.email);
      process.exit(0);
    }

    // Create super admin
    const superAdmin = await Admin.create({
      username: 'superadmin',
      email: 'admin@panngrillnext.com',
      password: 'Admin@123',
      fullName: 'Super Administrator',
      role: 'super-admin'
    });

    console.log('✅ Super admin created successfully!');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('📧 Username:', superAdmin.username);
    console.log('📧 Email:', superAdmin.email);
    console.log('🔑 Password: Admin@123');
    console.log('👤 Role:', superAdmin.role);
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('\n⚠️  IMPORTANT: Please change the password after first login!');
    console.log('🌐 Login at: http://localhost:3000/admin/login\n');

  } catch (error) {
    console.error('❌ Error creating super admin:', error.message);
  } finally {
    await mongoose.connection.close();
    console.log('🔌 Database connection closed');
  }
};

createSuperAdmin();
