const express = require('express');
const router = express.Router();
const authController = require('../controllers/adminAuthController');
const { protect, restrictTo } = require('../middleware/auth');

// ============================================
// PUBLIC ROUTES
// ============================================

// @route   POST /api/admin/auth/login
// @desc    Admin login
// @access  Public
router.post('/login', authController.login);

// @route   POST /api/admin/auth/public-signup
// @desc    Public admin signup
// @access  Public
router.post('/public-signup', authController.publicSignup);

// @route   POST /api/admin/auth/refresh
// @desc    Refresh access token
// @access  Public
router.post('/refresh', authController.refreshToken);

// @route   POST /api/admin/auth/forgot-password
// @desc    Request password reset
// @access  Public
router.post('/forgot-password', authController.forgotPassword);

// @route   POST /api/admin/auth/reset-password
// @desc    Reset password with token
// @access  Public
router.post('/reset-password', authController.resetPassword);

// ============================================
// PROTECTED ROUTES (Authenticated Admin)
// ============================================

// @route   POST /api/admin/auth/logout
// @desc    Admin logout
// @access  Private
router.post('/logout', protect, authController.logout);

// @route   GET /api/admin/auth/me
// @desc    Get current admin profile
// @access  Private
router.get('/me', protect, authController.getMe);

// @route   PUT /api/admin/auth/update-profile
// @desc    Update admin profile
// @access  Private
router.put('/update-profile', protect, authController.updateProfile);

// @route   PUT /api/admin/auth/change-password
// @desc    Change admin password
// @access  Private
router.put('/change-password', protect, authController.changePassword);

// ============================================
// SUPER-ADMIN ROUTES
// ============================================

// @route   POST /api/admin/auth/signup
// @desc    Create new admin (super-admin only)
// @access  Private (super-admin)
router.post('/signup', protect, restrictTo('super-admin'), authController.createAdmin);

// @route   GET /api/admin/auth/all
// @desc    Get all admins
// @access  Private (super-admin)
router.get('/all', protect, restrictTo('super-admin'), authController.getAllAdmins);

// @route   PUT /api/admin/auth/:id/toggle-status
// @desc    Toggle admin active status
// @access  Private (super-admin)
router.put('/:id/toggle-status', protect, restrictTo('super-admin'), authController.toggleAdminStatus);

// @route   DELETE /api/admin/auth/:id
// @desc    Delete admin
// @access  Private (super-admin)
router.delete('/:id', protect, restrictTo('super-admin'), authController.deleteAdmin);

module.exports = router;
