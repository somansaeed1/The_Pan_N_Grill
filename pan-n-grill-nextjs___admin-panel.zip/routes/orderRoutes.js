const express = require('express');
const router = express.Router();
const orderController = require('../controllers/orderController');
const { protect, restrictTo } = require('../middleware/auth');

// ============================================
// PUBLIC ROUTES
// ============================================

// @route   POST /api/orders
// @desc    Create new order
// @access  Public
router.post('/', orderController.createOrder);

// ============================================
// ADMIN ROUTES
// ============================================

// @route   GET /api/orders
// @desc    Get all orders with filters
// @access  Private (Admin)
router.get('/', protect, restrictTo('super-admin', 'admin', 'manager'), orderController.getAllOrders);

// @route   GET /api/orders/:id
// @desc    Get single order by ID
// @access  Private (Admin)
router.get('/:id', protect, restrictTo('super-admin', 'admin', 'manager'), orderController.getOrderById);

// @route   PATCH /api/orders/:id/status
// @desc    Update order status with validation
// @access  Private (Admin)
router.patch('/:id/status', protect, restrictTo('super-admin', 'admin', 'manager'), orderController.updateOrderStatus);

// @route   GET /api/orders/:id/status-history
// @desc    Get order status change history
// @access  Private (Admin)
router.get('/:id/status-history', protect, restrictTo('super-admin', 'admin', 'manager'), orderController.getOrderStatusHistory);

// @route   DELETE /api/orders/:id
// @desc    Delete order
// @access  Private (Super Admin)
router.delete('/:id', protect, restrictTo('super-admin'), orderController.deleteOrder);

module.exports = router;
