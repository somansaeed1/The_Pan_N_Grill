const express = require('express');
const router = express.Router();
const Category = require('../models/Category');
const Product = require('../models/Product');
const Order = require('../models/Order');
const { protect, restrictTo } = require('../middleware/auth');

// Middleware to check authentication for order searches
const checkOrderSearchAuth = async (req, res, next) => {
  const { type } = req.query;
  
  // If searching orders, require authentication
  if (!type || type === 'orders') {
    // Try to extract token
    let token;
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
      token = req.headers.authorization.split(' ')[1];
    }
    
    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required to search orders. Please provide a valid token.'
      });
    }
    
    // If token exists, verify it using protect middleware
    return protect(req, res, next);
  }
  
  // For other searches, continue without auth
  next();
};

// GET - Global search across all collections
router.get('/', checkOrderSearchAuth, async (req, res) => {
  try {
    const { q, type, minPrice, maxPrice, category, status } = req.query;

    if (!q && !minPrice && !maxPrice && !category && !status) {
      return res.status(400).json({
        success: false,
        message: 'Please provide at least one search parameter (q, minPrice, maxPrice, category, status)'
      });
    }

    const results = {
      categories: [],
      products: [],
      orders: []
    };

    // Search categories (if no specific type or type is 'categories')
    if (!type || type === 'categories') {
      if (q) {
        results.categories = await Category.find({
          $or: [
            { name: { $regex: q, $options: 'i' } },
            { description: { $regex: q, $options: 'i' } }
          ]
        });
      }
    }

    // Search products (if no specific type or type is 'products')
    if (!type || type === 'products') {
      let productQuery = {};

      if (q) {
        productQuery.$or = [
          { name: { $regex: q, $options: 'i' } },
          { description: { $regex: q, $options: 'i' } }
        ];
      }

      // Price range filter
      if (minPrice || maxPrice) {
        productQuery.price = {};
        if (minPrice) productQuery.price.$gte = parseFloat(minPrice);
        if (maxPrice) productQuery.price.$lte = parseFloat(maxPrice);
      }

      // Category filter
      if (category) {
        productQuery.category = category;
      }

      results.products = await Product.find(productQuery).populate('category');
    }

    // Search orders (if no specific type or type is 'orders') - ADMIN ONLY
    if (!type || type === 'orders') {
      // Authentication already checked by middleware
      // Additional role check
      const adminRoles = ['super-admin', 'admin', 'manager'];
      if (!req.admin || !adminRoles.includes(req.admin.role)) {
        return res.status(403).json({
          success: false,
          message: 'You do not have permission to search orders.'
        });
      }

      let orderQuery = {};

      if (q) {
        orderQuery.$or = [
          { orderNumber: { $regex: q, $options: 'i' } },
          { customerName: { $regex: q, $options: 'i' } },
          { customerEmail: { $regex: q, $options: 'i' } },
          { customerPhone: { $regex: q, $options: 'i' } }
        ];
      }

      // Status filter
      if (status) {
        orderQuery.status = status;
      }

      results.orders = await Order.find(orderQuery).populate('items.product');
    }

    const totalResults = results.categories.length + results.products.length + results.orders.length;

    res.status(200).json({
      success: true,
      query: q,
      filters: { type, minPrice, maxPrice, category, status },
      totalResults: totalResults,
      results: results
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

// GET - Search categories only
router.get('/categories', async (req, res) => {
  try {
    const { q, isActive } = req.query;

    if (!q) {
      return res.status(400).json({
        success: false,
        message: 'Please provide search query parameter (q)'
      });
    }

    let query = {
      $or: [
        { name: { $regex: q, $options: 'i' } },
        { description: { $regex: q, $options: 'i' } }
      ]
    };

    if (isActive !== undefined) {
      query.isActive = isActive === 'true';
    }

    const categories = await Category.find(query);

    res.status(200).json({
      success: true,
      query: q,
      count: categories.length,
      data: categories
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

// GET - Search products only
router.get('/products', async (req, res) => {
  try {
    const { q, minPrice, maxPrice, category, isAvailable, isVegetarian, spicyLevel } = req.query;

    if (!q && !minPrice && !maxPrice && !category) {
      return res.status(400).json({
        success: false,
        message: 'Please provide at least one search parameter'
      });
    }

    let query = {};

    // Text search
    if (q) {
      query.$or = [
        { name: { $regex: q, $options: 'i' } },
        { description: { $regex: q, $options: 'i' } }
      ];
    }

    // Price range
    if (minPrice || maxPrice) {
      query.price = {};
      if (minPrice) query.price.$gte = parseFloat(minPrice);
      if (maxPrice) query.price.$lte = parseFloat(maxPrice);
    }

    // Category filter
    if (category) {
      query.category = category;
    }

    // Availability filter
    if (isAvailable !== undefined) {
      query.isAvailable = isAvailable === 'true';
    }

    // Vegetarian filter
    if (isVegetarian !== undefined) {
      query.isVegetarian = isVegetarian === 'true';
    }

    // Spicy level filter
    if (spicyLevel) {
      query.spicyLevel = spicyLevel;
    }

    const products = await Product.find(query).populate('category');

    res.status(200).json({
      success: true,
      query: q,
      filters: { minPrice, maxPrice, category, isAvailable, isVegetarian, spicyLevel },
      count: products.length,
      data: products
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

// GET - Search orders only - ADMIN ONLY
router.get('/orders', protect, restrictTo('super-admin', 'admin', 'manager'), async (req, res) => {
  try {
    const { q, status, paymentStatus, orderType, minAmount, maxAmount, startDate, endDate } = req.query;

    if (!q && !status && !orderType && !startDate) {
      return res.status(400).json({
        success: false,
        message: 'Please provide at least one search parameter'
      });
    }

    let query = {};

    // Text search
    if (q) {
      query.$or = [
        { orderNumber: { $regex: q, $options: 'i' } },
        { customerName: { $regex: q, $options: 'i' } },
        { customerEmail: { $regex: q, $options: 'i' } },
        { customerPhone: { $regex: q, $options: 'i' } }
      ];
    }

    // Status filters
    if (status) {
      query.status = status;
    }

    if (paymentStatus) {
      query.paymentStatus = paymentStatus;
    }

    if (orderType) {
      query.orderType = orderType;
    }

    // Amount range
    if (minAmount || maxAmount) {
      query.totalAmount = {};
      if (minAmount) query.totalAmount.$gte = parseFloat(minAmount);
      if (maxAmount) query.totalAmount.$lte = parseFloat(maxAmount);
    }

    // Date range
    if (startDate || endDate) {
      query.createdAt = {};
      if (startDate) query.createdAt.$gte = new Date(startDate);
      if (endDate) query.createdAt.$lte = new Date(endDate);
    }

    const orders = await Order.find(query).populate('items.product').sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      query: q,
      filters: { status, paymentStatus, orderType, minAmount, maxAmount, startDate, endDate },
      count: orders.length,
      data: orders
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

module.exports = router;
