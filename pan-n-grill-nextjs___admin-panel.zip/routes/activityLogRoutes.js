const express = require('express');
const router = express.Router();
const activityLogController = require('../controllers/activityLogController');
const { protect, restrictTo } = require('../middleware/auth');

// ============================================
// ALL ROUTES ARE ADMIN-ONLY
// ============================================

// @route   GET /api/admin/activity-logs
// @desc    Get all activity logs with filters
// @access  Private (Admin)
router.get('/', protect, restrictTo('super-admin', 'admin', 'manager'), activityLogController.getAllLogs);

// @route   GET /api/admin/activity-logs/stats
// @desc    Get activity statistics
// @access  Private (Admin)
router.get('/stats', protect, restrictTo('super-admin', 'admin'), activityLogController.getActivityStats);

// @route   GET /api/admin/activity-logs/recent
// @desc    Get recent activity logs
// @access  Private (Admin)
router.get('/recent', protect, restrictTo('super-admin', 'admin', 'manager'), activityLogController.getRecentLogs);

// @route   GET /api/admin/activity-logs/me
// @desc    Get current admin's activity logs
// @access  Private (Admin)
router.get('/me', protect, restrictTo('super-admin', 'admin', 'manager'), activityLogController.getMyLogs);

// @route   GET /api/admin/activity-logs/admin/:adminId
// @desc    Get activity logs for specific admin
// @access  Private (Admin)
router.get('/admin/:adminId', protect, restrictTo('super-admin', 'admin'), activityLogController.getLogsByAdmin);

// @route   GET /api/admin/activity-logs/resource/:resourceType/:resourceId
// @desc    Get activity logs for specific resource
// @access  Private (Admin)
router.get('/resource/:resourceType/:resourceId', protect, restrictTo('super-admin', 'admin', 'manager'), activityLogController.getLogsByResource);

// @route   DELETE /api/admin/activity-logs/cleanup
// @desc    Delete old activity logs
// @access  Private (Super Admin only)
router.delete('/cleanup', protect, restrictTo('super-admin'), activityLogController.cleanupOldLogs);

module.exports = router;
