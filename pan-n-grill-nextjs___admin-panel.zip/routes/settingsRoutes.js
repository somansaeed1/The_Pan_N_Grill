const express = require('express');
const router = express.Router();
const settingsController = require('../controllers/settingsController');
const { protect, restrictTo } = require('../middleware/auth');

// ============================================
// PUBLIC ROUTE
// ============================================

// @route   GET /api/settings/public
// @desc    Get public settings
// @access  Public
router.get('/public', settingsController.getPublicSettings);

// ============================================
// ADMIN ROUTES
// ============================================

// @route   GET /api/admin/settings
// @desc    Get all settings (admin view)
// @access  Private (Admin)
router.get('/', protect, restrictTo('super-admin', 'admin', 'manager'), settingsController.getSettings);

// @route   PATCH /api/admin/settings/restaurant-info
// @desc    Update restaurant information
// @access  Private (Admin)
router.patch('/restaurant-info', protect, restrictTo('super-admin', 'admin'), settingsController.updateRestaurantInfo);

// @route   PATCH /api/admin/settings/tax
// @desc    Update tax settings
// @access  Private (Admin)
router.patch('/tax', protect, restrictTo('super-admin', 'admin'), settingsController.updateTaxSettings);

// @route   PATCH /api/admin/settings/delivery
// @desc    Update delivery settings
// @access  Private (Admin)
router.patch('/delivery', protect, restrictTo('super-admin', 'admin'), settingsController.updateDeliverySettings);

// @route   PATCH /api/admin/settings/toggle-status
// @desc    Toggle restaurant open/close status
// @access  Private (Admin)
router.patch('/toggle-status', protect, restrictTo('super-admin', 'admin', 'manager'), settingsController.toggleRestaurantStatus);

// @route   PATCH /api/admin/settings/payment
// @desc    Update payment settings
// @access  Private (Admin)
router.patch('/payment', protect, restrictTo('super-admin', 'admin'), settingsController.updatePaymentSettings);

// @route   PATCH /api/admin/settings/notifications
// @desc    Update notification settings
// @access  Private (Admin)
router.patch('/notifications', protect, restrictTo('super-admin', 'admin'), settingsController.updateNotificationSettings);

// @route   PATCH /api/admin/settings/operating-hours
// @desc    Update operating hours
// @access  Private (Admin)
router.patch('/operating-hours', protect, restrictTo('super-admin', 'admin'), settingsController.updateOperatingHours);

module.exports = router;
