const express = require('express');
const router = express.Router();
const dashboardController = require('../controllers/dashboardController');
const { protect, restrictTo } = require('../middleware/auth');

// All dashboard routes require admin authentication
router.use(protect);
router.use(restrictTo('super-admin', 'admin', 'manager'));

// @route   GET /api/admin/dashboard/stats
// @desc    Get main dashboard statistics (total orders, revenue, active orders, top products)
// @access  Private (Admin)
router.get('/stats', dashboardController.getDashboardStats);

// @route   GET /api/admin/dashboard/summary
// @desc    Get overall summary with all key metrics
// @access  Private (Admin)
router.get('/summary', dashboardController.getOverallSummary);

// @route   GET /api/admin/dashboard/recent-orders
// @desc    Get recent orders
// @access  Private (Admin)
router.get('/recent-orders', dashboardController.getRecentOrders);

// @route   GET /api/admin/dashboard/revenue-stats
// @desc    Get revenue statistics by period (day/week/month/year)
// @access  Private (Admin)
router.get('/revenue-stats', dashboardController.getRevenueStats);

// @route   GET /api/admin/dashboard/order-status
// @desc    Get order status distribution
// @access  Private (Admin)
router.get('/order-status', dashboardController.getOrderStatusDistribution);

// @route   GET /api/admin/dashboard/category-performance
// @desc    Get category performance statistics
// @access  Private (Admin)
router.get('/category-performance', dashboardController.getCategoryPerformance);

module.exports = router;
