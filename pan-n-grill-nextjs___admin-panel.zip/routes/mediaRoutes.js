const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');
const { uploadSingle, uploadMultiple } = require('../middleware/upload');
const { protect, restrictTo } = require('../middleware/auth');

// GET - List all media files - ADMIN ONLY
router.get('/', protect, restrictTo('super-admin', 'admin'), async (req, res) => {
  try {
    const { type = 'products' } = req.query;
    const uploadDir = path.join(__dirname, '..', 'uploads', type);

    if (!fs.existsSync(uploadDir)) {
      return res.status(404).json({
        success: false,
        message: `Media directory for type '${type}' not found`
      });
    }

    const files = fs.readdirSync(uploadDir);
    const fileDetails = files
      .filter(file => file !== '.gitkeep')
      .map(file => {
        const filePath = path.join(uploadDir, file);
        const stats = fs.statSync(filePath);
        return {
          filename: file,
          path: `/uploads/${type}/${file}`,
          url: `${req.protocol}://${req.get('host')}/uploads/${type}/${file}`,
          size: stats.size,
          uploadedAt: stats.birthtime
        };
      });

    res.status(200).json({
      success: true,
      count: fileDetails.length,
      type: type,
      data: fileDetails
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

// POST - Upload single image - ADMIN ONLY
router.post('/upload', protect, restrictTo('super-admin', 'admin'), (req, res) => {
  uploadSingle(req, res, function (err) {
    if (err) {
      return res.status(400).json({
        success: false,
        message: err.message
      });
    }

    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'No file uploaded'
      });
    }

    res.status(201).json({
      success: true,
      message: 'File uploaded successfully',
      data: {
        filename: req.file.filename,
        path: `/uploads/${req.file.destination.split('/')[1]}/${req.file.filename}`,
        url: `${req.protocol}://${req.get('host')}/uploads/${req.file.destination.split('/')[1]}/${req.file.filename}`,
        size: req.file.size,
        mimetype: req.file.mimetype
      }
    });
  });
});

// POST - Upload multiple images - ADMIN ONLY
router.post('/upload-multiple', protect, restrictTo('super-admin', 'admin'), (req, res) => {
  uploadMultiple(req, res, function (err) {
    if (err) {
      return res.status(400).json({
        success: false,
        message: err.message
      });
    }

    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No files uploaded'
      });
    }

    const uploadedFiles = req.files.map(file => ({
      filename: file.filename,
      path: `/uploads/${file.destination.split('/')[1]}/${file.filename}`,
      url: `${req.protocol}://${req.get('host')}/uploads/${file.destination.split('/')[1]}/${file.filename}`,
      size: file.size,
      mimetype: file.mimetype
    }));

    res.status(201).json({
      success: true,
      message: `${req.files.length} files uploaded successfully`,
      count: req.files.length,
      data: uploadedFiles
    });
  });
});

// GET - Get specific media file info - ADMIN ONLY
router.get('/:type/:filename', protect, restrictTo('super-admin', 'admin'), async (req, res) => {
  try {
    const { type, filename } = req.params;
    const filePath = path.join(__dirname, '..', 'uploads', type, filename);

    if (!fs.existsSync(filePath)) {
      return res.status(404).json({
        success: false,
        message: 'File not found'
      });
    }

    const stats = fs.statSync(filePath);
    
    res.status(200).json({
      success: true,
      data: {
        filename: filename,
        path: `/uploads/${type}/${filename}`,
        url: `${req.protocol}://${req.get('host')}/uploads/${type}/${filename}`,
        size: stats.size,
        uploadedAt: stats.birthtime,
        modifiedAt: stats.mtime
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

// DELETE - Delete a media file - ADMIN ONLY
router.delete('/:type/:filename', protect, restrictTo('super-admin', 'admin'), async (req, res) => {
  try {
    const { type, filename } = req.params;
    const filePath = path.join(__dirname, '..', 'uploads', type, filename);

    if (!fs.existsSync(filePath)) {
      return res.status(404).json({
        success: false,
        message: 'File not found'
      });
    }

    // Delete the file
    fs.unlinkSync(filePath);

    res.status(200).json({
      success: true,
      message: 'File deleted successfully',
      data: {
        filename: filename,
        type: type
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

module.exports = router;
