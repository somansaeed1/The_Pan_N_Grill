const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const { protect, restrictTo } = require('../middleware/auth');

// ============================================
// ALL ROUTES ARE ADMIN-ONLY
// ============================================

// @route   GET /api/users
// @desc    Get all users with filters
// @access  Private (Admin)
router.get('/', protect, restrictTo('super-admin', 'admin', 'manager'), userController.getAllUsers);

// @route   GET /api/users/:id
// @desc    Get single user by ID
// @access  Private (Admin)
router.get('/:id', protect, restrictTo('super-admin', 'admin', 'manager'), userController.getUserById);

// @route   GET /api/users/:id/orders
// @desc    Get user order history
// @access  Private (Admin)
router.get('/:id/orders', protect, restrictTo('super-admin', 'admin', 'manager'), userController.getUserOrderHistory);

// @route   GET /api/users/:id/stats
// @desc    Get user statistics
// @access  Private (Admin)
router.get('/:id/stats', protect, restrictTo('super-admin', 'admin', 'manager'), userController.getUserStats);

// @route   PATCH /api/users/:id/block
// @desc    Block user
// @access  Private (Admin)
router.patch('/:id/block', protect, restrictTo('super-admin', 'admin'), userController.blockUser);

// @route   PATCH /api/users/:id/unblock
// @desc    Unblock user
// @access  Private (Admin)
router.patch('/:id/unblock', protect, restrictTo('super-admin', 'admin'), userController.unblockUser);

// @route   DELETE /api/users/:id
// @desc    Delete user
// @access  Private (Super Admin)
router.delete('/:id', protect, restrictTo('super-admin'), userController.deleteUser);

module.exports = router;
