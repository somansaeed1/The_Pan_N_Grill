const express = require('express');
const router = express.Router();
const adminSearchController = require('../controllers/adminSearchController');
const { protect, restrictTo } = require('../middleware/auth');

// ============================================
// ALL ROUTES ARE ADMIN-ONLY
// ============================================

// @route   GET /api/admin/search
// @desc    Global search across all collections
// @access  Private (Admin)
router.get('/', protect, restrictTo('super-admin', 'admin', 'manager'), adminSearchController.globalSearch);

// @route   GET /api/admin/search/orders
// @desc    Search orders by ID, order number, customer info
// @access  Private (Admin)
router.get('/orders', protect, restrictTo('super-admin', 'admin', 'manager'), adminSearchController.searchOrders);

// @route   GET /api/admin/search/users
// @desc    Search users by email, name, phone
// @access  Private (Admin)
router.get('/users', protect, restrictTo('super-admin', 'admin', 'manager'), adminSearchController.searchUsers);

// @route   GET /api/admin/search/products
// @desc    Search products by name or category
// @access  Private (Admin)
router.get('/products', protect, restrictTo('super-admin', 'admin', 'manager'), adminSearchController.searchProducts);

// @route   GET /api/admin/search/quick
// @desc    Quick search for autocomplete (minimal data)
// @access  Private (Admin)
router.get('/quick', protect, restrictTo('super-admin', 'admin', 'manager'), adminSearchController.quickSearch);

module.exports = router;
