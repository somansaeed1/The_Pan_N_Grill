const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController');
const { protect, restrictTo } = require('../middleware/auth');
const { uploadSingle, handleMulterError } = require('../middleware/upload');

// ============================================
// PUBLIC ROUTES
// ============================================

// @route   GET /api/products
// @desc    Get all products (with filters)
// @access  Public
router.get('/', productController.getAllProducts);

// @route   GET /api/products/:id
// @desc    Get single product by ID
// @access  Public
router.get('/:id', productController.getProductById);

// ============================================
// ADMIN ROUTES
// ============================================

// @route   POST /api/products
// @desc    Create new product
// @access  Private (Admin)
router.post('/', protect, restrictTo('super-admin', 'admin'), productController.createProduct);

// @route   PUT /api/products/:id
// @desc    Update product
// @access  Private (Admin)
router.put('/:id', protect, restrictTo('super-admin', 'admin'), productController.updateProduct);

// @route   DELETE /api/products/:id
// @desc    Soft delete product
// @access  Private (Admin)
router.delete('/:id', protect, restrictTo('super-admin', 'admin'), productController.deleteProduct);

// @route   PATCH /api/products/:id/availability
// @desc    Toggle product availability
// @access  Private (Admin)
router.patch('/:id/availability', protect, restrictTo('super-admin', 'admin'), productController.toggleAvailability);

// @route   PATCH /api/products/:id/restore
// @desc    Restore soft-deleted product
// @access  Private (Admin)
router.patch('/:id/restore', protect, restrictTo('super-admin', 'admin'), productController.restoreProduct);

// @route   DELETE /api/products/:id/permanent
// @desc    Permanently delete product
// @access  Private (Super Admin only)
router.delete('/:id/permanent', protect, restrictTo('super-admin'), productController.permanentDeleteProduct);

// @route   PATCH /api/products/bulk/availability
// @desc    Bulk update product availability
// @access  Private (Admin)
router.patch('/bulk/availability', protect, restrictTo('super-admin', 'admin'), productController.bulkUpdateAvailability);

// ============================================
// IMAGE UPLOAD ROUTES
// ============================================

// @route   POST /api/products/:id/upload-image
// @desc    Upload product image
// @access  Private (Admin)
router.post(
  '/:id/upload-image',
  protect,
  restrictTo('super-admin', 'admin'),
  uploadSingle,
  handleMulterError,
  productController.uploadProductImage
);

// @route   DELETE /api/products/:id/image
// @desc    Delete product image
// @access  Private (Admin)
router.delete('/:id/image', protect, restrictTo('super-admin', 'admin'), productController.deleteProductImage);

module.exports = router;
