require('dotenv').config();
const mongoose = require('mongoose');
const Category = require('./models/Category');
const Product = require('./models/Product');

// Sample data
const categories = [
  {
    name: 'Burgers',
    description: 'Juicy grilled burgers made with premium ingredients',
    image: '/images/burgers/burger-icon.jpg',
    isActive: true,
    displayOrder: 1
  },
  {
    name: 'Pizzas',
    description: 'Fresh wood-fired pizzas with authentic Italian flavors',
    image: '/images/pizzas/pizza-icon.jpg',
    isActive: true,
    displayOrder: 2
  },
  {
    name: 'Shawarmas',
    description: 'Authentic Middle Eastern shawarmas',
    image: '/images/shawarmas/shawarma-icon.jpg',
    isActive: true,
    displayOrder: 3
  },
  {
    name: 'Beverages',
    description: 'Refreshing drinks and beverages',
    image: '/images/beverages/beverage-icon.jpg',
    isActive: true,
    displayOrder: 4
  }
];

async function seedDatabase() {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('✅ Connected to MongoDB');

    // Clear existing data
    await Category.deleteMany({});
    await Product.deleteMany({});
    console.log('🗑️  Cleared existing data');

    // Insert categories
    const insertedCategories = await Category.insertMany(categories);
    console.log(`✅ Inserted ${insertedCategories.length} categories`);

    // Create products for each category
    const products = [];

    // Burgers
    const burgerCategory = insertedCategories.find(c => c.name === 'Burgers');
    products.push(
      {
        name: 'Classic Beef Burger',
        description: 'Juicy beef patty with lettuce, tomato, onion, and special sauce',
        price: 12.99,
        category: burgerCategory._id,
        image: '/images/burgers/classic-burger.jpg',
        isAvailable: true,
        isVegetarian: false,
        spicyLevel: 'mild',
        preparationTime: 15,
        calories: 650
      },
      {
        name: 'Cheese Burger Deluxe',
        description: 'Double beef patty with cheddar cheese, bacon, and BBQ sauce',
        price: 15.99,
        category: burgerCategory._id,
        image: '/images/burgers/cheese-burger.jpg',
        isAvailable: true,
        isVegetarian: false,
        spicyLevel: 'none',
        preparationTime: 18,
        calories: 850
      },
      {
        name: 'Veggie Burger',
        description: 'Plant-based patty with fresh vegetables and avocado',
        price: 11.99,
        category: burgerCategory._id,
        image: '/images/burgers/veggie-burger.jpg',
        isAvailable: true,
        isVegetarian: true,
        spicyLevel: 'none',
        preparationTime: 12,
        calories: 450
      }
    );

    // Pizzas
    const pizzaCategory = insertedCategories.find(c => c.name === 'Pizzas');
    products.push(
      {
        name: 'Margherita Pizza',
        description: 'Classic pizza with tomato sauce, mozzarella, and basil',
        price: 14.99,
        category: pizzaCategory._id,
        image: '/images/pizzas/margherita.jpg',
        isAvailable: true,
        isVegetarian: true,
        spicyLevel: 'none',
        preparationTime: 20,
        calories: 700
      },
      {
        name: 'Pepperoni Supreme',
        description: 'Loaded with pepperoni, cheese, and Italian herbs',
        price: 17.99,
        category: pizzaCategory._id,
        image: '/images/pizzas/pepperoni.jpg',
        isAvailable: true,
        isVegetarian: false,
        spicyLevel: 'mild',
        preparationTime: 22,
        calories: 900
      }
    );

    // Shawarmas
    const shawarmaCategory = insertedCategories.find(c => c.name === 'Shawarmas');
    products.push(
      {
        name: 'Chicken Shawarma',
        description: 'Tender chicken with tahini sauce and pickles',
        price: 9.99,
        category: shawarmaCategory._id,
        image: '/images/shawarmas/chicken-shawarma.jpg',
        isAvailable: true,
        isVegetarian: false,
        spicyLevel: 'medium',
        preparationTime: 10,
        calories: 550
      },
      {
        name: 'Beef Shawarma',
        description: 'Marinated beef with garlic sauce and vegetables',
        price: 10.99,
        category: shawarmaCategory._id,
        image: '/images/shawarmas/beef-shawarma.jpg',
        isAvailable: true,
        isVegetarian: false,
        spicyLevel: 'hot',
        preparationTime: 12,
        calories: 600
      }
    );

    // Beverages
    const beverageCategory = insertedCategories.find(c => c.name === 'Beverages');
    products.push(
      {
        name: 'Fresh Orange Juice',
        description: 'Freshly squeezed orange juice',
        price: 4.99,
        category: beverageCategory._id,
        image: '/images/beverages/orange-juice.jpg',
        isAvailable: true,
        isVegetarian: true,
        spicyLevel: 'none',
        preparationTime: 3,
        calories: 120
      },
      {
        name: 'Mango Smoothie',
        description: 'Creamy mango smoothie with yogurt',
        price: 5.99,
        category: beverageCategory._id,
        image: '/images/beverages/mango-smoothie.jpg',
        isAvailable: true,
        isVegetarian: true,
        spicyLevel: 'none',
        preparationTime: 5,
        calories: 180
      }
    );

    // Insert products
    const insertedProducts = await Product.insertMany(products);
    console.log(`✅ Inserted ${insertedProducts.length} products`);

    console.log('\n✨ Database seeded successfully!');
    console.log('\n📊 Summary:');
    console.log(`   Categories: ${insertedCategories.length}`);
    console.log(`   Products: ${insertedProducts.length}`);
    console.log('\n🚀 You can now test the API with Postman!\n');

  } catch (error) {
    console.error('❌ Error seeding database:', error);
  } finally {
    await mongoose.disconnect();
    console.log('🔌 Disconnected from MongoDB');
  }
}

// Run the seed function
seedDatabase();
